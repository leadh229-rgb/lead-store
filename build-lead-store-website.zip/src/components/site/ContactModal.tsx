"use client";

import { useEffect, useState } from "react";
import { Check, Copy, Crown, ExternalLink, ShoppingBag, X } from "lucide-react";
import { BrandIcon } from "@/components/icons";
import { useStore } from "./StoreProvider";

function CopyChip({ text, label }: { text: string; label: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      type="button"
      aria-label={label}
      onClick={async (e) => {
        e.preventDefault();
        e.stopPropagation();
        try {
          await navigator.clipboard.writeText(text);
          setCopied(true);
          setTimeout(() => setCopied(false), 1600);
        } catch {
          /* clipboard unavailable */
        }
      }}
      className="flex shrink-0 items-center gap-1.5 rounded-lg border border-white/15 bg-black/30 px-2.5 py-1.5 text-[11px] font-bold text-white/70 transition hover:border-white/40 hover:text-white"
    >
      {copied ? (
        <Check className="h-3.5 w-3.5 text-lead-400" />
      ) : (
        <Copy className="h-3.5 w-3.5" />
      )}
      {copied ? "تم النسخ" : "نسخ"}
    </button>
  );
}

export default function ContactModal({
  open,
  productName,
  onClose,
}: {
  open: boolean;
  productName?: string;
  onClose: () => void;
}) {
  const { settings } = useStore();

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);

  if (!open) return null;

  const storeName = settings.store_name || "LEAD STORE";
  const message = productName
    ? `السلام عليكم، أبي أطلب «${productName}» من ${storeName} ⚡`
    : `السلام عليكم، أبي أستفسر عن خدمات ${storeName} ⚡`;
  const waLink = `https://wa.me/${settings.whatsapp}?text=${encodeURIComponent(message)}`;
  const discordLink = settings.discord_url;
  const discordShort = discordLink.replace(/^https?:\/\//, "");

  return (
    <div
      className="fade-in fixed inset-0 z-50 flex items-end justify-center bg-black/75 p-4 backdrop-blur-sm sm:items-center"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label="تواصل معنا"
    >
      <div
        className="modal-pop relative w-full max-w-md overflow-hidden rounded-3xl border border-lead-500/25 bg-night-800 shadow-[0_0_80px_rgba(0,230,118,0.18)]"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="pointer-events-none absolute -top-24 left-1/2 h-48 w-72 -translate-x-1/2 rounded-full bg-lead-500/20 blur-3xl" />

        <div className="relative p-6 pb-5">
          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق"
            className="absolute left-4 top-4 rounded-full border border-white/10 bg-white/5 p-2 text-white/60 transition hover:rotate-90 hover:border-white/30 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>

          <h3 className="font-display text-2xl font-bold text-white">
            تواصل معنا <span className="text-gradient">الآن</span>
          </h3>
          <p className="mt-1 text-sm text-white/55">
            اختر طريقة التواصل اللي تناسبك وبنخدمك بأسرع وقت
          </p>

          {productName && (
            <div className="mt-4 flex items-center gap-2 rounded-xl border border-lead-500/30 bg-lead-500/10 px-3.5 py-2.5 text-sm font-bold text-lead-300">
              <ShoppingBag className="h-4 w-4 shrink-0" />
              <span className="truncate">طلبك: {productName}</span>
            </div>
          )}

          <div className="mt-5 space-y-3">
            {/* واتساب */}
            <div className="group flex items-center gap-2 rounded-2xl border border-[#25d366]/30 bg-gradient-to-l from-[#25d366]/15 to-transparent p-2 transition hover:border-[#25d366]/70 hover:shadow-[0_0_30px_rgba(37,211,102,0.2)]">
              <a
                href={waLink}
                target="_blank"
                rel="noopener noreferrer"
                className="flex flex-1 items-center gap-3 rounded-xl p-2"
              >
                <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-[#25d366] text-night-950 shadow-[0_4px_18px_rgba(37,211,102,0.45)] transition group-hover:scale-110">
                  <BrandIcon name="whatsapp" className="h-6 w-6" />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block font-display text-base font-bold text-white">
                    واتساب
                  </span>
                  <span className="block truncate text-xs text-white/55" dir="ltr">
                    {settings.whatsapp_display}
                  </span>
                </span>
                <ExternalLink className="h-4 w-4 shrink-0 text-white/40 transition group-hover:text-[#25d366]" />
              </a>
              <CopyChip text={settings.whatsapp_display} label="نسخ رقم الواتساب" />
            </div>

            {/* ديسكورد */}
            <div className="group flex items-center gap-2 rounded-2xl border border-blurple/35 bg-gradient-to-l from-blurple/15 to-transparent p-2 transition hover:border-blurple/80 hover:shadow-[0_0_30px_rgba(88,101,242,0.25)]">
              <a
                href={discordLink}
                target="_blank"
                rel="noopener noreferrer"
                className="flex flex-1 items-center gap-3 rounded-xl p-2"
              >
                <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-blurple text-white shadow-[0_4px_18px_rgba(88,101,242,0.5)] transition group-hover:scale-110">
                  <BrandIcon name="discord" className="h-6 w-6" />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block font-display text-base font-bold text-white">
                    سيرفر ديسكورد
                  </span>
                  <span className="block truncate text-xs text-white/55" dir="ltr">
                    {discordShort}
                  </span>
                </span>
                <ExternalLink className="h-4 w-4 shrink-0 text-white/40 transition group-hover:text-blurple" />
              </a>
              <CopyChip text={discordLink} label="نسخ رابط الديسكورد" />
            </div>
          </div>

          <div className="mt-5 flex items-center justify-center gap-2 rounded-xl bg-black/30 px-3 py-2.5 text-center text-[11px] font-bold text-lead-300/90">
            <Crown className="h-3.5 w-3.5 shrink-0 text-neonlime" />
            {settings.premium_note}
          </div>
        </div>
      </div>
    </div>
  );
}