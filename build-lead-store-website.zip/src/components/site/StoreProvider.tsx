"use client";

import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { Headset } from "lucide-react";
import type { SettingsMap } from "@/lib/defaults";
import ContactModal from "./ContactModal";

interface StoreContextValue {
  settings: SettingsMap;
  openContact: (productName?: string) => void;
}

const StoreContext = createContext<StoreContextValue | null>(null);

export function useStore(): StoreContextValue {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useStore must be used within StoreProvider");
  return ctx;
}

export default function StoreProvider({
  settings,
  children,
}: {
  settings: SettingsMap;
  children: ReactNode;
}) {
  const [contactOpen, setContactOpen] = useState(false);
  const [productName, setProductName] = useState<string | undefined>(undefined);

  const openContact = useCallback((name?: string) => {
    setProductName(name);
    setContactOpen(true);
  }, []);

  const value = useMemo(
    () => ({ settings, openContact }),
    [settings, openContact]
  );

  return (
    <StoreContext.Provider value={value}>
      {children}

      {/* زر التواصل العائم */}
      <button
        type="button"
        onClick={() => openContact()}
        className="group fixed bottom-6 left-5 z-40 flex items-center gap-2.5 rounded-full bg-gradient-to-l from-lead-600 to-lead-500 py-3 pl-5 pr-4 font-display text-sm font-bold text-night-950 shadow-[0_8px_30px_rgba(0,230,118,0.4)] transition-transform duration-300 hover:scale-105 active:scale-95"
        aria-label="تواصل معنا"
      >
        <span className="absolute inset-0 -z-10 rounded-full bg-lead-500 ring-pulse" />
        <Headset className="h-5 w-5 transition-transform group-hover:-rotate-12" />
        <span>تواصل معنا</span>
      </button>

      <ContactModal
        open={contactOpen}
        productName={productName}
        onClose={() => setContactOpen(false)}
      />
    </StoreContext.Provider>
  );
}