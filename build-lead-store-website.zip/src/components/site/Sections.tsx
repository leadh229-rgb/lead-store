"use client";

import {
  ChevronDown,
  ChevronLeft,
  Crown,
  DollarSign,
  Headset,
  Lock,
  MessagesSquare,
  MousePointerClick,
  Rocket,
  ShieldCheck,
  ShoppingCart,
  Sparkles,
  Trophy,
  Zap,
  type LucideIcon,
} from "lucide-react";
import { BrandIcon, RobuxIcon } from "@/components/icons";
import Reveal from "./Reveal";
import { useStore } from "./StoreProvider";

/* ====== عنوان قسم ====== */
export function SectionHeading({
  icon: Icon,
  title,
  subtitle,
}: {
  icon: LucideIcon;
  title: string;
  subtitle: string;
}) {
  return (
    <Reveal className="mb-10">
      <div className="flex items-center gap-4">
        <span className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-neonlime via-lead-500 to-lead-700 text-night-950 shadow-[0_0_30px_rgba(0,230,118,0.35)]">
          <Icon className="h-7 w-7" strokeWidth={2.2} />
        </span>
        <div>
          <h2 className="font-display text-3xl font-extrabold text-white sm:text-4xl">
            {title}
          </h2>
          <p className="mt-1 text-sm text-white/50">{subtitle}</p>
        </div>
        <span className="mr-2 hidden h-px flex-1 bg-gradient-to-l from-lead-500/50 to-transparent sm:block" />
      </div>
    </Reveal>
  );
}

/* ====== الشريط المتحرك ====== */
export function Marquee() {
  const items: { icon: LucideIcon | null; brand?: "roblox" | "twitter" | "kick" | "discord"; label: string }[] = [
    { icon: null, brand: "roblox", label: "متابعين روبلوكس" },
    { icon: Zap, label: "تسليم خلال دقائق" },
    { icon: null, brand: "roblox", label: "أعضاء قروبات روبلوكس" },
    { icon: ShieldCheck, label: "ضمان تعويض النقصان" },
    { icon: null, brand: "twitter", label: "لايكات تويتر X" },
    { icon: Crown, label: "دفع روبوكس للبريميوم" },
    { icon: null, brand: "kick", label: "لايكات كيك Kick" },
    { icon: Headset, label: "دعم فني على مدار الساعة" },
    { icon: null, brand: "discord", label: "نيترو وإفكتات ديسكورد" },
    { icon: Sparkles, label: "أسعار ما تتفوّت" },
  ];
  const doubled = [...items, ...items];
  return (
    <div className="relative overflow-hidden border-y border-lead-500/15 bg-night-800/70 py-3.5">
      <div className="marquee-track flex w-max items-center">
        {doubled.map((item, i) => (
          <span
            key={i}
            className="flex items-center gap-2.5 whitespace-nowrap pl-10 text-sm font-bold text-white/55"
          >
            {item.brand ? (
              <BrandIcon name={item.brand} className="h-4 w-4 text-lead-400" />
            ) : item.icon ? (
              <item.icon className="h-4 w-4 text-lead-400" />
            ) : null}
            {item.label}
            <span className="mr-6 h-1.5 w-1.5 rounded-full bg-lead-500/40" />
          </span>
        ))}
      </div>
    </div>
  );
}

/* ====== كيف تطلب ====== */
export function HowItWorks() {
  const steps = [
    {
      icon: MousePointerClick,
      title: "اختر خدمتك",
      desc: "تصفح قسم الرشق أو المبيعات واختر الخدمة اللي تبيها.",
    },
    {
      icon: ShoppingCart,
      title: "اضغط «اطلب الآن»",
      desc: "بيظهر لك زر التواصل مع تفاصيل طلبك جاهزة.",
    },
    {
      icon: MessagesSquare,
      title: "تواصل معنا",
      desc: "واتساب أو ديسكورد، أرسل لنا رابط حسابك وأكّد الدفع.",
    },
    {
      icon: Rocket,
      title: "استلم خلال دقائق",
      desc: "ننفذ طلبك فورًا وبأمان تام مع متابعة حتى الاكتمال.",
    },
  ];
  return (
    <section id="how" className="relative mx-auto max-w-7xl scroll-mt-24 px-4 py-20 sm:px-6">
      <SectionHeading
        icon={MousePointerClick}
        title="كيف تطلب؟"
        subtitle="أربع خطوات بسيطة وتوصلك الخدمة"
      />
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {steps.map((step, i) => (
          <Reveal key={step.title} delay={i * 110}>
            <div className="group relative h-full overflow-hidden rounded-2xl border border-white/8 bg-white/[0.025] p-6 transition duration-300 hover:-translate-y-1.5 hover:border-lead-500/35 hover:bg-lead-500/[0.04]">
              <span className="pointer-events-none absolute -left-1 -top-4 font-brand text-7xl font-black text-white/[0.045] transition group-hover:text-lead-500/10">
                {String(i + 1).padStart(2, "0")}
              </span>
              <span className="relative grid h-12 w-12 place-items-center rounded-xl border border-lead-500/30 bg-lead-500/10 text-lead-400 transition group-hover:scale-110 group-hover:bg-lead-500 group-hover:text-night-950">
                <step.icon className="h-6 w-6" />
              </span>
              <h3 className="relative mt-4 font-display text-lg font-bold text-white">
                {step.title}
              </h3>
              <p className="relative mt-1.5 text-xs leading-relaxed text-white/50">
                {step.desc}
              </p>
              {i < steps.length - 1 && (
                <ChevronLeft className="absolute left-4 bottom-5 hidden h-5 w-5 text-lead-500/40 lg:block" />
              )}
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

/* ====== الأسئلة الشائعة ====== */
export function Faq() {
  const faqs = [
    {
      q: "كيف أستلم طلبي؟",
      a: "بعد ما تتواصل معنا وتؤكد الدفع، نبدأ التنفيذ فورًا ويكتمل طلبك غالبًا خلال دقائق معدودة، ونوافيك بالتحديث أول بأول.",
    },
    {
      q: "وش يعني الدفع بالروبوكس لأصحاب البريميوم؟",
      a: "خيار الدفع بالروبوكس (مثلاً 500 روبوكس لكل 1000 متابع روبلوكس) متاح حصريًا للاعبي روبلوكس أصحاب عضوية البريميوم، ويتم عبر وسيلة دفع داخل روبلوكس نتفق عليها بالخاص.",
    },
    {
      q: "هل الرشق آمن على حسابي؟",
      a: "نعم، نستخدم طرق آمنة تمامًا ولا نطلب كلمة مرورك أبدًا. كل اللي نحتاجه هو رابط حسابك أو تغريدتك أو قروبك فقط.",
    },
    {
      q: "هل يوجد ضمان على الخدمات؟",
      a: "أكيد، جميع خدمات الرشق عليها ضمان تعويض النقصان خلال فترة الضمان، وإذا صار أي خلل نعوضك بدون أي رسوم إضافية.",
    },
    {
      q: "ما هي طرق الدفع المتاحة؟",
      a: "الدفع بالدولار (تحويل أو وسائل دفع نتفق عليها)، ولأصحاب بريميوم روبلوكس فقط يتوفر الدفع بالروبوكس بالسعر الموضح بالإطار الأخضر اللامع.",
    },
  ];
  return (
    <section id="faq" className="mx-auto max-w-3xl scroll-mt-24 px-4 py-20 sm:px-6">
      <Reveal className="mb-10 text-center">
        <span className="inline-grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-neonlime via-lead-500 to-lead-700 text-night-950 shadow-[0_0_30px_rgba(0,230,118,0.35)]">
          <MessagesSquare className="h-7 w-7" />
        </span>
        <h2 className="mt-4 font-display text-3xl font-extrabold text-white sm:text-4xl">
          الأسئلة الشائعة
        </h2>
        <p className="mt-2 text-sm text-white/50">كل اللي تحتاج تعرفه قبل ما تطلب</p>
      </Reveal>
      <div className="space-y-3">
        {faqs.map((f, i) => (
          <Reveal key={f.q} delay={i * 70}>
            <details className="faq group rounded-2xl border border-white/8 bg-white/[0.025] transition open:border-lead-500/35 open:bg-lead-500/[0.04]">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-3 px-5 py-4 font-display text-sm font-bold text-white transition hover:text-lead-300 sm:text-base">
                {f.q}
                <ChevronDown className="faq-chevron h-5 w-5 shrink-0 text-lead-400 transition-transform duration-300" />
              </summary>
              <p className="px-5 pb-5 text-sm leading-relaxed text-white/55">{f.a}</p>
            </details>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

/* ====== بانر الدعوة ====== */
export function CtaBanner() {
  const { openContact } = useStore();
  return (
    <section className="mx-auto max-w-7xl px-4 pb-24 sm:px-6">
      <Reveal>
        <div className="relative overflow-hidden rounded-3xl border border-lead-500/30 bg-gradient-to-br from-night-700 via-night-800 to-night-900 px-6 py-14 text-center sm:px-12">
          <div className="pointer-events-none absolute -top-24 left-1/2 h-64 w-[480px] -translate-x-1/2 rounded-full bg-lead-500/20 blur-[100px]" />
          <Zap className="float-slow pointer-events-none absolute right-8 top-8 h-10 w-10 text-lead-500/25" />
          <Trophy className="float-slower pointer-events-none absolute bottom-8 left-8 h-10 w-10 text-neonlime/20" />
          <h2 className="relative font-display text-3xl font-extrabold text-white sm:text-5xl">
            جاهز تصير <span className="text-gradient">ليد</span>؟ 🏆
          </h2>
          <p className="relative mx-auto mt-3 max-w-xl text-sm leading-relaxed text-white/55 sm:text-base">
            انضم لآلاف العملاء اللي رفعوا أرقامهم معنا — اطلب الآن وبننفذ لك بأسرع وقت
          </p>
          <div className="relative mt-8 flex flex-wrap items-center justify-center gap-3">
            <button
              type="button"
              onClick={() => openContact()}
              className="btn-sheen flex items-center gap-2 rounded-2xl bg-gradient-to-l from-lead-600 via-lead-500 to-neonlime px-8 py-3.5 font-display text-base font-bold text-night-950 shadow-[0_10px_36px_rgba(0,230,118,0.4)] transition hover:-translate-y-0.5 active:scale-95"
            >
              <Headset className="h-5 w-5" />
              اطلب الآن
            </button>
            <a
              href="#boost"
              className="flex items-center gap-2 rounded-2xl border border-white/15 bg-white/5 px-8 py-3.5 font-display text-base font-bold text-white/80 transition hover:-translate-y-0.5 hover:border-lead-500/40 hover:text-lead-300 active:scale-95"
            >
              تصفح الخدمات
            </a>
          </div>
        </div>
      </Reveal>
    </section>
  );
}

/* ====== الفوتر ====== */
export function Footer() {
  const { settings, openContact } = useStore();
  const waLink = `https://wa.me/${settings.whatsapp}`;
  return (
    <footer className="border-t border-white/5 bg-night-900/80">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-3">
        <div>
          <div className="flex items-center gap-2.5">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-neonlime via-lead-500 to-lead-700 text-night-950">
              <Zap className="h-5 w-5" strokeWidth={2.6} />
            </span>
            <span className="font-brand text-lg font-extrabold text-gradient">
              {settings.store_name}
            </span>
          </div>
          <p className="mt-4 max-w-xs text-sm leading-relaxed text-white/45">
            {settings.footer_text}
          </p>
          <div className="mt-5 flex items-center gap-2">
            <a
              href={waLink}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="واتساب"
              className="grid h-10 w-10 place-items-center rounded-xl border border-white/10 bg-white/5 text-[#25d366] transition hover:-translate-y-1 hover:border-[#25d366]/50"
            >
              <BrandIcon name="whatsapp" className="h-4.5 w-4.5" />
            </a>
            <a
              href={settings.discord_url}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="ديسكورد"
              className="grid h-10 w-10 place-items-center rounded-xl border border-white/10 bg-white/5 text-blurple transition hover:-translate-y-1 hover:border-blurple/60"
            >
              <BrandIcon name="discord" className="h-4.5 w-4.5" />
            </a>
          </div>
        </div>

        <div>
          <h4 className="font-display text-base font-bold text-white">روابط سريعة</h4>
          <ul className="mt-4 space-y-2.5 text-sm text-white/50">
            {[
              { href: "#boost", label: "قسم الرشق" },
              { href: "#shop", label: "قسم المبيعات" },
              { href: "#how", label: "كيف تطلب؟" },
              { href: "#faq", label: "الأسئلة الشائعة" },
            ].map((l) => (
              <li key={l.href}>
                <a
                  href={l.href}
                  className="inline-flex items-center gap-1.5 transition hover:text-lead-300"
                >
                  <ChevronLeft className="h-3.5 w-3.5 text-lead-500/60" />
                  {l.label}
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="font-display text-base font-bold text-white">طرق الدفع</h4>
          <div className="mt-4 flex flex-wrap gap-2.5">
            <span className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm font-bold text-white/75">
              <DollarSign className="h-4 w-4 text-lead-400" />
              دولار أمريكي
            </span>
            <span className="premium-frame flex items-center gap-2 px-4 py-2.5 text-sm font-bold text-lead-300">
              <RobuxIcon className="relative z-10 h-4 w-4 text-neonlime" />
              <span className="relative z-10">روبوكس</span>
              <Crown className="relative z-10 h-3.5 w-3.5 text-neonlime" />
            </span>
          </div>
          <p className="mt-3 text-[11px] leading-relaxed text-white/40">
            {settings.premium_note}
          </p>
          <button
            type="button"
            onClick={() => openContact()}
            className="mt-4 flex items-center gap-2 text-sm font-bold text-lead-400 transition hover:text-lead-300"
          >
            <Headset className="h-4 w-4" />
            تواصل معنا الآن
          </button>
        </div>
      </div>

      <div className="border-t border-white/5 py-5">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 text-[11px] font-bold text-white/35 sm:px-6">
          <span>
            © {new Date().getFullYear()} {settings.store_name} — جميع الحقوق محفوظة
          </span>
          <a
            href="/admin"
            className="flex items-center gap-1.5 rounded-lg border border-white/10 px-3 py-1.5 transition hover:border-lead-500/40 hover:text-lead-300"
          >
            <Lock className="h-3 w-3" />
            لوحة التحكم
          </a>
        </div>
      </div>
    </footer>
  );
}