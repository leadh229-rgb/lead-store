"use client";

import { useEffect, useRef, useState } from "react";
import {
  BadgeCheck,
  Crown,
  Headset,
  PackageCheck,
  Rocket,
  Star,
  Users,
  Zap,
} from "lucide-react";
import { BrandIcon, RobuxIcon } from "@/components/icons";
import type { Product } from "@/lib/defaults";
import { useStore } from "./StoreProvider";

function CountUp({ value, decimals = 0 }: { value: number; decimals?: number }) {
  const ref = useRef<HTMLSpanElement>(null);
  const [display, setDisplay] = useState(0);
  const started = useRef(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      (entries) => {
        if (!entries[0].isIntersecting || started.current) return;
        started.current = true;
        const start = performance.now();
        const duration = 1400;
        const tick = (now: number) => {
          const t = Math.min(1, (now - start) / duration);
          const eased = 1 - Math.pow(1 - t, 3);
          setDisplay(value * eased);
          if (t < 1) requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
        observer.disconnect();
      },
      { threshold: 0.4 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [value]);

  return (
    <span ref={ref} className="font-brand tabular-nums" dir="ltr">
      {display.toLocaleString("en-US", {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals,
      })}
    </span>
  );
}

export default function Hero({ products }: { products: Product[] }) {
  const { settings, openContact } = useStore();
  const boostImg =
    products.find((p) => p.category === "boost")?.image ??
    "/images/products/roblox-followers.jpg";
  const shopImg =
    products.find((p) => p.category === "shop")?.image ??
    "/images/products/discord-nitro.jpg";

  const stats = [
    {
      icon: PackageCheck,
      value: Number(settings.stat_orders) || 0,
      decimals: 0,
      prefix: "+",
      label: "طلب مكتمل",
    },
    {
      icon: Users,
      value: Number(settings.stat_clients) || 0,
      decimals: 0,
      prefix: "+",
      label: "عميل يثق فينا",
    },
    {
      icon: Star,
      value: Number(settings.stat_rating) || 0,
      decimals: 1,
      prefix: "",
      label: "تقييم العملاء",
    },
  ];

  return (
    <section id="home" className="relative overflow-hidden">
      {/* طبقات الخلفية */}
      <div className="bg-grid absolute inset-0" />
      <div className="pointer-events-none absolute -top-32 right-[8%] h-[480px] w-[480px] rounded-full bg-lead-600/20 blur-[130px]" />
      <div className="pointer-events-none absolute top-40 left-[2%] h-72 w-72 rounded-full bg-neonlime/10 blur-[110px]" />

      <div className="relative mx-auto grid max-w-7xl items-center gap-14 px-4 pb-20 pt-14 sm:px-6 lg:grid-cols-2 lg:pb-28 lg:pt-20">
        {/* النص */}
        <div>
          <div className="inline-flex items-center gap-2 rounded-full border border-lead-500/30 bg-lead-500/10 px-4 py-1.5 text-xs font-bold text-lead-300">
            <BadgeCheck className="h-4 w-4" />
            المتجر الموثوق رقم 1 للخدمات الرقمية
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-lead-400 opacity-75" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-lead-500" />
            </span>
          </div>

          <h1 className="mt-5 font-brand text-5xl font-black leading-none tracking-tight sm:text-6xl xl:text-7xl">
            <span className="text-gradient drop-shadow-[0_0_30px_rgba(0,230,118,0.35)]">
              {settings.store_name}
            </span>
          </h1>
          <p className="mt-4 font-display text-3xl font-bold leading-snug text-white sm:text-4xl">
            {settings.hero_title}
          </p>
          <p className="mt-4 max-w-xl text-base leading-relaxed text-white/55">
            {settings.hero_subtitle}
          </p>

          <div className="mt-8 flex flex-wrap items-center gap-3">
            <a
              href="#boost"
              className="btn-sheen flex items-center gap-2 rounded-2xl bg-gradient-to-l from-lead-600 via-lead-500 to-neonlime px-7 py-3.5 font-display text-base font-bold text-night-950 shadow-[0_10px_36px_rgba(0,230,118,0.4)] transition hover:-translate-y-0.5 hover:shadow-[0_14px_44px_rgba(0,230,118,0.55)] active:scale-95"
            >
              <Rocket className="h-5 w-5" />
              تصفح قسم الرشق
            </a>
            <button
              type="button"
              onClick={() => openContact()}
              className="flex items-center gap-2 rounded-2xl border border-lead-500/40 bg-lead-500/5 px-7 py-3.5 font-display text-base font-bold text-lead-300 transition hover:-translate-y-0.5 hover:border-lead-400 hover:bg-lead-500/15 active:scale-95"
            >
              <Headset className="h-5 w-5" />
              تواصل معنا
            </button>
          </div>

          {/* إحصائيات */}
          <div className="mt-10 flex max-w-lg items-stretch justify-between gap-2 rounded-2xl border border-white/8 bg-white/[0.03] px-5 py-4">
            {stats.map((s, i) => (
              <div key={s.label} className="flex items-center gap-2">
                {i > 0 && <span className="ml-3 hidden h-10 w-px bg-white/10 sm:block" />}
                <s.icon className="h-5 w-5 shrink-0 text-lead-400" />
                <div>
                  <div className="text-lg font-extrabold text-white sm:text-xl">
                    {s.prefix}
                    <CountUp value={s.value} decimals={s.decimals} />
                  </div>
                  <div className="text-[10px] font-bold text-white/45 sm:text-[11px]">
                    {s.label}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* المشهد البصري */}
        <div className="relative mx-auto hidden h-[440px] w-full max-w-md sm:block">
          {/* الحلقة المركزية */}
          <div className="absolute left-1/2 top-1/2 h-80 w-80 -translate-x-1/2 -translate-y-1/2">
            <div className="spin-slow absolute inset-0 rounded-full border-2 border-dashed border-lead-500/25" />
            <div className="absolute inset-6 rounded-full border border-lead-500/15 bg-gradient-to-br from-lead-600/15 via-transparent to-neonlime/10 backdrop-blur-sm" />
            <div className="absolute inset-0 grid place-items-center">
              <span className="grid h-28 w-28 place-items-center rounded-3xl bg-gradient-to-br from-neonlime via-lead-500 to-lead-700 text-night-950 shadow-[0_0_70px_rgba(0,230,118,0.55)]">
                <Zap className="h-14 w-14" strokeWidth={2.4} />
              </span>
            </div>
            {/* أيقونات المنصات على المدار */}
            <span className="absolute -top-3 left-1/2 grid h-11 w-11 -translate-x-1/2 place-items-center rounded-xl border border-white/10 bg-night-700 text-lead-300 shadow-lg">
              <BrandIcon name="roblox" className="h-5 w-5" />
            </span>
            <span className="absolute top-1/2 -right-3 grid h-11 w-11 -translate-y-1/2 place-items-center rounded-xl border border-white/10 bg-night-700 text-white shadow-lg">
              <BrandIcon name="twitter" className="h-4.5 w-4.5" />
            </span>
            <span className="absolute -bottom-3 left-1/2 grid h-11 w-11 -translate-x-1/2 place-items-center rounded-xl border border-white/10 bg-night-700 text-lead-400 shadow-lg">
              <BrandIcon name="kick" className="h-5 w-5" />
            </span>
            <span className="absolute top-1/2 -left-3 grid h-11 w-11 -translate-y-1/2 place-items-center rounded-xl border border-white/10 bg-night-700 text-blurple shadow-lg">
              <BrandIcon name="discord" className="h-5 w-5" />
            </span>
          </div>

          {/* بطاقة متابعين عائمة */}
          <div className="float-slow absolute right-0 top-4 w-52 rounded-2xl border border-lead-500/30 bg-night-800/90 p-3 shadow-[0_20px_50px_rgba(0,0,0,0.5)] backdrop-blur">
            <div className="flex items-center gap-3">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={boostImg}
                alt="متابعين روبلوكس"
                className="h-12 w-12 rounded-xl object-cover"
              />
              <div className="min-w-0">
                <div className="truncate text-xs font-bold text-white">
                  +1000 متابع روبلوكس
                </div>
                <div className="mt-0.5 font-brand text-sm font-bold text-lead-400" dir="ltr">
                  $5
                </div>
              </div>
            </div>
            <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/10">
              <div className="h-full w-[86%] rounded-full bg-gradient-to-l from-lead-500 to-neonlime" />
            </div>
            <div className="mt-1.5 text-[10px] font-bold text-white/40">
              اكتمل الطلب خلال 4 دقائق ⚡
            </div>
          </div>

          {/* بطاقة نيترو عائمة */}
          <div className="float-slower absolute bottom-6 left-0 w-48 rounded-2xl border border-blurple/40 bg-night-800/90 p-3 shadow-[0_20px_50px_rgba(0,0,0,0.5)] backdrop-blur">
            <div className="flex items-center gap-3">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={shopImg}
                alt="نيترو ديسكورد"
                className="h-12 w-12 rounded-xl object-cover"
              />
              <div className="min-w-0">
                <div className="truncate text-xs font-bold text-white">نيترو ديسكورد</div>
                <div className="mt-0.5 text-[10px] font-bold text-blurple">
                  تفعيل فوري ✔
                </div>
              </div>
            </div>
          </div>

          {/* شارة الروبوكس بريميوم */}
          <div className="float-slow absolute left-2 top-10 premium-frame px-3.5 py-2" style={{ animationDelay: "1.2s" }}>
            <div className="flex items-center gap-2 text-xs font-bold text-lead-300">
              <RobuxIcon className="h-4 w-4 text-neonlime" />
              <span dir="ltr" className="font-brand">500</span>
              روبوكس
              <Crown className="h-3.5 w-3.5 text-neonlime" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}