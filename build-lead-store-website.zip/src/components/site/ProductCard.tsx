"use client";

import { Crown, ShieldCheck, ShoppingCart, Zap } from "lucide-react";
import { BrandIcon, RobuxIcon } from "@/components/icons";
import { PLATFORM_LABELS, type Product } from "@/lib/defaults";
import { useStore } from "./StoreProvider";

export function formatUsd(price: string): string {
  const n = Number(price);
  if (!Number.isFinite(n)) return price;
  return n % 1 === 0 ? String(n) : n.toFixed(2);
}

/** إطار الروبوكس الأخضر اللامع — حصري لأصحاب البريميوم */
export function RobuxBadge({
  product,
  note,
}: {
  product: Product;
  note: string;
}) {
  if (product.robuxPrice === null) return null;
  return (
    <div className="premium-frame shrink-0 px-3.5 py-2 text-center" title={note}>
      <div className="relative z-10 flex items-center justify-center gap-1.5">
        <RobuxIcon className="h-4 w-4 text-neonlime" />
        <span className="font-brand text-base font-bold text-white" dir="ltr">
          {product.robuxPrice.toLocaleString("en-US")}
        </span>
        <span className="text-[11px] font-bold text-lead-300">روبوكس</span>
      </div>
      <div className="relative z-10 mt-1 flex items-center justify-center gap-1 text-[9px] font-extrabold tracking-wide text-neonlime">
        <Crown className="h-3 w-3" />
        {product.premiumOnly ? "لأصحاب البريميوم فقط" : "دفع بالروبوكس"}
      </div>
    </div>
  );
}

export default function ProductCard({
  product,
  wide = false,
}: {
  product: Product;
  wide?: boolean;
}) {
  const { settings, openContact } = useStore();

  return (
    <article
      className={`group relative overflow-hidden rounded-3xl border bg-gradient-to-b from-night-700/70 to-night-800 transition-all duration-300 hover:-translate-y-2 hover:border-lead-500/45 hover:shadow-[0_24px_60px_rgba(0,230,118,0.14)] ${
        product.featured
          ? "border-lead-500/35 shadow-[0_0_40px_rgba(0,230,118,0.08)]"
          : "border-white/8"
      } ${wide ? "grid sm:grid-cols-[240px_1fr]" : "flex flex-col"}`}
    >
      {/* الصورة */}
      <div className={`relative overflow-hidden ${wide ? "h-52 sm:h-full" : "h-44"}`}>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={product.image}
          alt={product.name}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
        />
        <div
          className={`absolute inset-0 bg-gradient-to-t from-night-800 via-transparent to-transparent ${
            wide ? "sm:bg-gradient-to-r" : ""
          }`}
        />
        {/* شارة المنصة */}
        <span className="absolute right-3 top-3 flex items-center gap-1.5 rounded-full border border-white/15 bg-black/65 px-3 py-1.5 text-[10px] font-bold text-white backdrop-blur">
          <BrandIcon name={product.platform} className="h-3.5 w-3.5 text-lead-400" />
          {PLATFORM_LABELS[product.platform]}
        </span>
        {product.badge && (
          <span className="absolute left-3 top-3 rounded-full bg-gradient-to-l from-lead-600 to-neonlime px-3 py-1.5 text-[10px] font-extrabold text-night-950 shadow-[0_4px_16px_rgba(0,230,118,0.4)]">
            {product.badge}
          </span>
        )}
      </div>

      {/* المحتوى */}
      <div className="flex flex-1 flex-col p-5">
        <h3 className="font-display text-lg font-bold leading-snug text-white transition group-hover:text-lead-300">
          {product.name}
        </h3>
        <p className="mt-1.5 line-clamp-2 text-xs leading-relaxed text-white/50">
          {product.description}
        </p>

        <div className="mt-3 flex items-center gap-3 text-[10px] font-bold text-white/40">
          <span className="flex items-center gap-1">
            <Zap className="h-3 w-3 text-lead-400" /> تسليم سريع
          </span>
          <span className="flex items-center gap-1">
            <ShieldCheck className="h-3 w-3 text-lead-400" /> ضمان تعويض
          </span>
        </div>

        {/* الأسعار */}
        <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
          <div>
            <div
              className="font-brand text-3xl font-extrabold leading-none text-white"
              dir="ltr"
            >
              ${formatUsd(product.priceUsd)}
            </div>
            <div className="mt-1.5 text-[10px] font-bold text-white/45">
              {product.unit}
            </div>
          </div>
          <RobuxBadge product={product} note={settings.premium_note} />
        </div>

        <button
          type="button"
          onClick={() => openContact(product.name)}
          className={`btn-sheen mt-5 flex items-center justify-center gap-2 rounded-xl bg-gradient-to-l from-lead-600 to-lead-500 py-3 font-display text-sm font-bold text-night-950 shadow-[0_6px_22px_rgba(0,230,118,0.28)] transition hover:shadow-[0_8px_30px_rgba(0,230,118,0.5)] active:scale-95 ${
            wide ? "sm:w-fit sm:px-10" : "w-full"
          }`}
        >
          <ShoppingCart className="h-4 w-4" />
          اطلب الآن
        </button>
      </div>
    </article>
  );
}