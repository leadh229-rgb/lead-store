"use client";

import { useEffect, useState } from "react";
import { Megaphone, Menu, MessageCircle, X, Zap } from "lucide-react";
import { useStore } from "./StoreProvider";

const LINKS = [
  { href: "#home", label: "الرئيسية" },
  { href: "#boost", label: "قسم الرشق" },
  { href: "#shop", label: "قسم المبيعات" },
  { href: "#how", label: "كيف تطلب؟" },
  { href: "#faq", label: "الأسئلة الشائعة" },
];

export default function Header() {
  const { settings, openContact } = useStore();
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header className="sticky top-0 z-40">
      {/* شريط الإعلانات */}
      <div className="flex items-center justify-center gap-2 bg-gradient-to-l from-lead-700 via-lead-600 to-lead-700 px-4 py-1.5 text-center text-[11px] font-bold text-night-950 sm:text-xs">
        <Megaphone className="h-3.5 w-3.5 shrink-0 animate-pulse" />
        <span className="truncate">{settings.announcement}</span>
      </div>

      <div
        className={`border-b transition-all duration-300 ${
          scrolled
            ? "border-lead-500/15 bg-night-950/90 shadow-[0_10px_40px_rgba(0,0,0,0.5)] backdrop-blur-xl"
            : "border-white/5 bg-night-950/60 backdrop-blur-md"
        }`}
      >
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6">
          {/* الشعار */}
          <a href="#home" className="group flex items-center gap-2.5">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-neonlime via-lead-500 to-lead-700 text-night-950 shadow-[0_0_20px_rgba(0,230,118,0.45)] transition-transform duration-300 group-hover:rotate-12">
              <Zap className="h-5 w-5" strokeWidth={2.6} />
            </span>
            <span className="leading-none">
              <span className="block font-brand text-lg font-extrabold tracking-wide text-gradient">
                {settings.store_name}
              </span>
              <span className="mt-1 block text-[10px] font-bold text-white/45">
                متجر ليد للخدمات الرقمية
              </span>
            </span>
          </a>

          {/* روابط سطح المكتب */}
          <nav className="hidden items-center gap-1 lg:flex">
            {LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="group relative rounded-lg px-3.5 py-2 text-sm font-bold text-white/65 transition hover:text-lead-300"
              >
                {link.label}
                <span className="absolute bottom-0.5 right-3.5 left-3.5 h-0.5 origin-right scale-x-0 rounded-full bg-gradient-to-l from-lead-500 to-neonlime transition-transform duration-300 group-hover:scale-x-100" />
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => openContact()}
              className="btn-sheen hidden items-center gap-2 rounded-xl bg-gradient-to-l from-lead-600 to-lead-500 px-4 py-2.5 text-sm font-bold text-night-950 shadow-[0_4px_20px_rgba(0,230,118,0.35)] transition hover:shadow-[0_4px_28px_rgba(0,230,118,0.55)] active:scale-95 sm:flex"
            >
              <MessageCircle className="h-4 w-4" />
              تواصل معنا
            </button>
            <button
              type="button"
              aria-label="القائمة"
              onClick={() => setMenuOpen((v) => !v)}
              className="grid h-10 w-10 place-items-center rounded-xl border border-white/10 bg-white/5 text-white/80 transition hover:border-lead-500/40 lg:hidden"
            >
              {menuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>

        {/* قائمة الجوال */}
        {menuOpen && (
          <nav className="fade-in border-t border-white/5 bg-night-900/95 px-4 py-3 backdrop-blur-xl lg:hidden">
            <div className="grid gap-1">
              {LINKS.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={() => setMenuOpen(false)}
                  className="rounded-xl px-4 py-3 text-sm font-bold text-white/75 transition hover:bg-lead-500/10 hover:text-lead-300"
                >
                  {link.label}
                </a>
              ))}
              <button
                type="button"
                onClick={() => {
                  setMenuOpen(false);
                  openContact();
                }}
                className="mt-1 flex items-center justify-center gap-2 rounded-xl bg-gradient-to-l from-lead-600 to-lead-500 px-4 py-3 text-sm font-bold text-night-950"
              >
                <MessageCircle className="h-4 w-4" />
                تواصل معنا
              </button>
            </div>
          </nav>
        )}
      </div>
    </header>
  );
}