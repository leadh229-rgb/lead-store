"use client";

import { useCallback, useEffect, useState } from "react";
import {
  AlertCircle,
  CheckCircle2,
  ExternalLink,
  Eye,
  Loader2,
  LogOut,
  Package,
  Pencil,
  Plus,
  Rocket,
  Search,
  Settings,
  ShoppingBag,
  Star,
  Trash2,
  X,
  Zap,
} from "lucide-react";
import { BrandIcon, RobuxIcon } from "@/components/icons";
import {
  PLATFORM_LABELS,
  type Product,
  type SettingsMap,
} from "@/lib/defaults";
import { formatUsd } from "@/components/site/ProductCard";
import {
  adminAuthHeaders,
  clearAdminToken,
  setAdminToken,
} from "@/lib/adminClient";
import ProductForm from "./ProductForm";
import SettingsForm from "./SettingsForm";

interface Toast {
  message: string;
  ok: boolean;
}

export default function AdminDashboard({ onLogout }: { onLogout: () => void }) {
  const [tab, setTab] = useState<"products" | "settings">("products");
  const [products, setProducts] = useState<Product[]>([]);
  const [settings, setSettings] = useState<SettingsMap | null>(null);
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState<Toast | null>(null);
  const [formProduct, setFormProduct] = useState<Product | "new" | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<number | null>(null);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<"all" | "boost" | "shop">("all");

  const notify = useCallback((message: string, ok = true) => {
    setToast({ message, ok });
    window.setTimeout(() => setToast(null), 2800);
  }, []);

  const api = useCallback(
    async (url: string, options?: RequestInit) => {
      const res = await fetch(url, {
        ...options,
        cache: "no-store",
        headers: {
          "Content-Type": "application/json",
          ...adminAuthHeaders(),
          ...options?.headers,
        },
      });
      if (res.status === 401) {
        clearAdminToken();
        onLogout();
        throw new Error("انتهت الجلسة، سجل الدخول من جديد");
      }
      const data = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) throw new Error(data.error || "حدث خطأ غير متوقع");
      return data;
    },
    [onLogout]
  );

  const load = useCallback(async () => {
    try {
      const [pData, sData] = await Promise.all([
        api("/api/admin/products"),
        api("/api/admin/settings"),
      ]);
      setProducts((pData as { products: Product[] }).products);
      setSettings((sData as { settings: SettingsMap }).settings);
    } catch (err) {
      notify(err instanceof Error ? err.message : "تعذر تحميل البيانات", false);
    } finally {
      setLoading(false);
    }
  }, [api, notify]);

  useEffect(() => {
    void load();
  }, [load]);

  const saveProduct = async (input: Record<string, unknown>, id?: number) => {
    try {
      if (id) {
        await api(`/api/admin/products/${id}`, {
          method: "PUT",
          body: JSON.stringify(input),
        });
        notify("تم تحديث المنتج بنجاح ✔");
      } else {
        await api("/api/admin/products", {
          method: "POST",
          body: JSON.stringify(input),
        });
        notify("تمت إضافة المنتج بنجاح ✔");
      }
      setFormProduct(null);
      await load();
    } catch (err) {
      notify(err instanceof Error ? err.message : "تعذر الحفظ", false);
      throw err;
    }
  };

  const toggleActive = async (p: Product) => {
    try {
      await api(`/api/admin/products/${p.id}`, {
        method: "PUT",
        body: JSON.stringify({ active: !p.active }),
      });
      notify(p.active ? "تم إخفاء المنتج من المتجر" : "تم تفعيل المنتج في المتجر");
      await load();
    } catch (err) {
      notify(err instanceof Error ? err.message : "تعذر التحديث", false);
    }
  };

  const removeProduct = async (id: number) => {
    try {
      await api(`/api/admin/products/${id}`, { method: "DELETE" });
      notify("تم حذف المنتج نهائيًا");
      setConfirmDelete(null);
      await load();
    } catch (err) {
      notify(err instanceof Error ? err.message : "تعذر الحذف", false);
    }
  };

  const saveSettings = async (map: SettingsMap) => {
    try {
      await api("/api/admin/settings", {
        method: "PUT",
        body: JSON.stringify({ settings: map }),
      });
      // لو تغيّرت كلمة السر نجدد الجلسة تلقائيًا
      if (settings && map.admin_password && map.admin_password !== settings.admin_password) {
        const relogin = await fetch("/api/admin/login", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ password: map.admin_password }),
          cache: "no-store",
        });
        const reloginData = (await relogin.json().catch(() => ({}))) as {
          token?: string;
        };
        if (reloginData.token) setAdminToken(reloginData.token);
        notify("تم حفظ الإعدادات وتحديث كلمة السر ✔");
      } else {
        notify("تم حفظ الإعدادات بنجاح ✔");
      }
      await load();
    } catch (err) {
      notify(err instanceof Error ? err.message : "تعذر حفظ الإعدادات", false);
      throw err;
    }
  };

  const logout = async () => {
    await fetch("/api/admin/logout", { method: "POST", headers: adminAuthHeaders() });
    clearAdminToken();
    onLogout();
  };

  const filtered = products.filter((p) => {
    const matchQuery =
      !query ||
      p.name.includes(query) ||
      p.description.includes(query) ||
      PLATFORM_LABELS[p.platform].includes(query);
    const matchFilter = filter === "all" || p.category === filter;
    return matchQuery && matchFilter;
  });

  const stats = [
    { icon: Package, label: "إجمالي المنتجات", value: products.length },
    { icon: Rocket, label: "خدمات الرشق", value: products.filter((p) => p.category === "boost").length },
    { icon: ShoppingBag, label: "منتجات المبيعات", value: products.filter((p) => p.category === "shop").length },
    { icon: Eye, label: "المنتجات النشطة", value: products.filter((p) => p.active).length },
  ];

  return (
    <div className="relative min-h-screen pb-24">
      <div className="bg-grid pointer-events-none absolute inset-0 h-96" />

      {/* الشريط العلوي */}
      <header className="sticky top-0 z-30 border-b border-lead-500/15 bg-night-950/90 backdrop-blur-xl">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4 sm:px-6">
          <div className="flex items-center gap-2.5">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-neonlime via-lead-500 to-lead-700 text-night-950">
              <Zap className="h-5 w-5" strokeWidth={2.6} />
            </span>
            <div className="leading-none">
              <span className="block font-brand text-base font-extrabold text-gradient">
                LEAD STORE
              </span>
              <span className="mt-1 block text-[10px] font-bold text-white/45">
                لوحة التحكم — إدارة المتجر
              </span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <a
              href="/"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 rounded-xl border border-white/10 bg-white/5 px-3.5 py-2 text-xs font-bold text-white/70 transition hover:border-lead-500/40 hover:text-lead-300"
            >
              <ExternalLink className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">عرض المتجر</span>
            </a>
            <button
              type="button"
              onClick={logout}
              className="flex items-center gap-1.5 rounded-xl border border-red-500/25 bg-red-500/10 px-3.5 py-2 text-xs font-bold text-red-300 transition hover:bg-red-500/20"
            >
              <LogOut className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">خروج</span>
            </button>
          </div>
        </div>
      </header>

      <main className="relative mx-auto max-w-6xl px-4 pt-8 sm:px-6">
        {/* الإحصائيات */}
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          {stats.map((s) => (
            <div
              key={s.label}
              className="rounded-2xl border border-white/8 bg-white/[0.03] p-4 transition hover:border-lead-500/30"
            >
              <div className="flex items-center gap-2 text-[11px] font-bold text-white/45">
                <s.icon className="h-4 w-4 text-lead-400" />
                {s.label}
              </div>
              <div className="mt-2 font-brand text-2xl font-extrabold text-white">
                {s.value}
              </div>
            </div>
          ))}
        </div>

        {/* التبويبات */}
        <div className="mt-8 flex items-center gap-2 border-b border-white/8 pb-px">
          {(
            [
              { id: "products", label: "المنتجات", icon: Package },
              { id: "settings", label: "إعدادات المتجر", icon: Settings },
            ] as const
          ).map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id)}
              className={`flex items-center gap-2 rounded-t-xl border-b-2 px-5 py-3 text-sm font-bold transition ${
                tab === t.id
                  ? "border-lead-500 bg-lead-500/10 text-lead-300"
                  : "border-transparent text-white/50 hover:text-white"
              }`}
            >
              <t.icon className="h-4 w-4" />
              {t.label}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="grid place-items-center py-24">
            <Loader2 className="h-8 w-8 animate-spin text-lead-500" />
          </div>
        ) : tab === "settings" ? (
          settings && <SettingsForm settings={settings} onSave={saveSettings} />
        ) : (
          <div className="mt-6">
            {/* أدوات */}
            <div className="flex flex-wrap items-center gap-3">
              <div className="relative min-w-52 flex-1">
                <Search className="absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-white/35" />
                <input
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="ابحث عن منتج…"
                  className="field pr-10"
                />
              </div>
              <select
                value={filter}
                onChange={(e) => setFilter(e.target.value as typeof filter)}
                className="field w-auto cursor-pointer"
              >
                <option value="all">كل الأقسام</option>
                <option value="boost">قسم الرشق</option>
                <option value="shop">قسم المبيعات</option>
              </select>
              <button
                type="button"
                onClick={() => setFormProduct("new")}
                className="btn-sheen flex items-center gap-2 rounded-xl bg-gradient-to-l from-lead-600 to-lead-500 px-5 py-2.5 text-sm font-bold text-night-950 transition active:scale-95"
              >
                <Plus className="h-4 w-4" />
                منتج جديد
              </button>
            </div>

            {/* قائمة المنتجات */}
            <div className="mt-5 space-y-3">
              {filtered.length === 0 && (
                <div className="rounded-2xl border border-dashed border-white/15 py-16 text-center text-sm font-bold text-white/40">
                  ما فيه منتجات مطابقة — جرّب بحث ثاني أو أضف منتج جديد
                </div>
              )}
              {filtered.map((p) => (
                <div
                  key={p.id}
                  className={`flex flex-wrap items-center gap-4 rounded-2xl border bg-white/[0.025] p-3.5 transition hover:border-lead-500/30 ${
                    p.active ? "border-white/8" : "border-white/5 opacity-60"
                  }`}
                >
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={p.image}
                    alt={p.name}
                    className="h-14 w-14 shrink-0 rounded-xl border border-white/10 object-cover"
                  />
                  <div className="min-w-0 flex-1 basis-44">
                    <div className="flex items-center gap-2">
                      <span className="truncate font-display text-sm font-bold text-white">
                        {p.name}
                      </span>
                      {p.featured && <Star className="h-3.5 w-3.5 shrink-0 fill-neonlime text-neonlime" />}
                    </div>
                    <div className="mt-1.5 flex flex-wrap items-center gap-2 text-[10px] font-bold">
                      <span className="flex items-center gap-1 rounded-full border border-white/10 bg-black/40 px-2 py-0.5 text-white/60">
                        <BrandIcon name={p.platform} className="h-3 w-3 text-lead-400" />
                        {PLATFORM_LABELS[p.platform]}
                      </span>
                      <span
                        className={`rounded-full px-2 py-0.5 ${
                          p.category === "boost"
                            ? "bg-lead-500/15 text-lead-300"
                            : "bg-blurple/20 text-[#aab4ff]"
                        }`}
                      >
                        {p.category === "boost" ? "رشق" : "مبيعات"}
                      </span>
                    </div>
                  </div>

                  <div className="text-center">
                    <div className="font-brand text-base font-extrabold text-white" dir="ltr">
                      ${formatUsd(p.priceUsd)}
                    </div>
                    <div className="text-[9px] font-bold text-white/35">{p.unit || "—"}</div>
                  </div>

                  <div className="w-20 text-center">
                    {p.robuxPrice !== null ? (
                      <span className="inline-flex items-center gap-1 rounded-lg border border-lead-500/30 bg-lead-500/10 px-2 py-1 text-[11px] font-bold text-lead-300">
                        <RobuxIcon className="h-3 w-3 text-neonlime" />
                        <span dir="ltr">{p.robuxPrice}</span>
                      </span>
                    ) : (
                      <span className="text-[10px] text-white/25">بدون روبوكس</span>
                    )}
                  </div>

                  {/* مفتاح التفعيل */}
                  <button
                    type="button"
                    onClick={() => toggleActive(p)}
                    title={p.active ? "ظاهر في المتجر — اضغط للإخفاء" : "مخفي — اضغط للتفعيل"}
                    className={`relative h-6 w-11 shrink-0 rounded-full transition ${
                      p.active ? "bg-lead-500" : "bg-white/15"
                    }`}
                  >
                    <span
                      className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${
                        p.active ? "right-0.5" : "right-[22px]"
                      }`}
                    />
                  </button>

                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => setFormProduct(p)}
                      className="flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-[11px] font-bold text-white/75 transition hover:border-lead-500/50 hover:text-lead-300"
                    >
                      <Pencil className="h-3.5 w-3.5" />
                      تعديل
                    </button>
                    {confirmDelete === p.id ? (
                      <span className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => removeProduct(p.id)}
                          className="rounded-lg bg-red-500 px-3 py-2 text-[11px] font-bold text-white transition hover:bg-red-600"
                        >
                          تأكيد الحذف؟
                        </button>
                        <button
                          type="button"
                          onClick={() => setConfirmDelete(null)}
                          aria-label="إلغاء"
                          className="grid h-8 w-8 place-items-center rounded-lg border border-white/10 text-white/50 hover:text-white"
                        >
                          <X className="h-3.5 w-3.5" />
                        </button>
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setConfirmDelete(p.id)}
                        className="flex items-center gap-1.5 rounded-lg border border-red-500/20 bg-red-500/5 px-3 py-2 text-[11px] font-bold text-red-300/80 transition hover:bg-red-500/15 hover:text-red-300"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                        حذف
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* نموذج المنتج */}
      {formProduct && (
        <ProductForm
          product={formProduct === "new" ? null : formProduct}
          onClose={() => setFormProduct(null)}
          onSave={saveProduct}
        />
      )}

      {/* التوست */}
      {toast && (
        <div
          className={`modal-pop fixed bottom-6 right-6 z-[70] flex items-center gap-2.5 rounded-2xl border px-5 py-3.5 text-sm font-bold shadow-2xl backdrop-blur ${
            toast.ok
              ? "border-lead-500/40 bg-night-700/95 text-lead-300"
              : "border-red-500/40 bg-night-700/95 text-red-300"
          }`}
        >
          {toast.ok ? (
            <CheckCircle2 className="h-5 w-5 text-lead-400" />
          ) : (
            <AlertCircle className="h-5 w-5 text-red-400" />
          )}
          {toast.message}
        </div>
      )}
    </div>
  );
}