"use client";

import { useState } from "react";
import {
  Crown,
  Info,
  Loader2,
  Lock,
  MessageCircle,
  Save,
  Store,
  type LucideIcon,
} from "lucide-react";
import type { SettingsMap } from "@/lib/defaults";
import { sanitizePassword } from "@/lib/sanitize";

interface FieldDef {
  key: string;
  label: string;
  hint?: string;
  textarea?: boolean;
  ltr?: boolean;
  number?: boolean;
  step?: string;
}

const SECTIONS: { title: string; icon: LucideIcon; fields: FieldDef[] }[] = [
  {
    title: "هوية المتجر والنصوص",
    icon: Store,
    fields: [
      { key: "store_name", label: "اسم المتجر", hint: "يظهر بالشعار والعنوان" },
      { key: "announcement", label: "شريط الإعلان العلوي" },
      { key: "hero_title", label: "العنوان الرئيسي (الواجهة)" },
      { key: "hero_subtitle", label: "الوصف الرئيسي", textarea: true },
      { key: "boost_title", label: "عنوان قسم الرشق" },
      { key: "boost_subtitle", label: "وصف قسم الرشق" },
      { key: "shop_title", label: "عنوان قسم المبيعات" },
      { key: "shop_subtitle", label: "وصف قسم المبيعات" },
      { key: "footer_text", label: "نبذة الفوتر", textarea: true },
    ],
  },
  {
    title: "روابط التواصل",
    icon: MessageCircle,
    fields: [
      {
        key: "whatsapp",
        label: "رقم الواتساب (بصيغة دولية بدون +)",
        hint: "مثال: 212664562982 — يُستخدم لرابط wa.me",
        ltr: true,
      },
      { key: "whatsapp_display", label: "الرقم المعروض للزوار", ltr: true },
      { key: "discord_url", label: "رابط سيرفر الديسكورد", ltr: true },
    ],
  },
  {
    title: "البريميوم والإحصائيات",
    icon: Crown,
    fields: [
      {
        key: "premium_note",
        label: "تنبيه الدفع بالروبوكس",
        hint: "يظهر بنافذة التواصل وتحت الإطارات الخضراء اللامعة",
      },
      { key: "stat_orders", label: "عدد الطلبات المكتملة (الواجهة)", number: true },
      { key: "stat_clients", label: "عدد العملاء (الواجهة)", number: true },
      { key: "stat_rating", label: "التقييم من 5", number: true, step: "0.1" },
    ],
  },
  {
    title: "الأمان",
    icon: Lock,
    fields: [
      {
        key: "admin_password",
        label: "كلمة سر لوحة التحكم",
        hint: "عند تغييرها سيتم تجديد جلستك تلقائيًا — احفظها جيدًا",
        ltr: true,
      },
    ],
  },
];

export default function SettingsForm({
  settings,
  onSave,
}: {
  settings: SettingsMap;
  onSave: (map: SettingsMap) => Promise<void>;
}) {
  const [form, setForm] = useState<SettingsMap>({ ...settings });
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      await onSave(form);
    } catch {
      /* التوست يظهر من اللوحة */
    } finally {
      setBusy(false);
    }
  };

  return (
    <form onSubmit={submit} className="mt-6 space-y-6">
      <div className="flex items-center gap-2.5 rounded-2xl border border-lead-500/25 bg-lead-500/[0.06] px-4 py-3 text-xs font-bold text-lead-300">
        <Info className="h-4 w-4 shrink-0" />
        كل التعديلات هنا تنعكس على المتجر مباشرة بعد الحفظ — عدّل النصوص والأسعار والروابط براحتك.
      </div>

      {SECTIONS.map((section) => (
        <div
          key={section.title}
          className="rounded-3xl border border-white/8 bg-white/[0.02] p-6"
        >
          <h3 className="flex items-center gap-2.5 font-display text-base font-bold text-white">
            <span className="grid h-9 w-9 place-items-center rounded-xl border border-lead-500/30 bg-lead-500/10 text-lead-400">
              <section.icon className="h-4.5 w-4.5" />
            </span>
            {section.title}
          </h3>
          <div className="mt-5 grid gap-4 sm:grid-cols-2">
            {section.fields.map((field) => (
              <label
                key={field.key}
                className={`block text-xs font-bold text-white/60 ${
                  field.textarea ? "sm:col-span-2" : ""
                }`}
              >
                {field.label}
                {field.textarea ? (
                  <textarea
                    value={form[field.key] ?? ""}
                    onChange={(e) =>
                      setForm((f) => ({ ...f, [field.key]: e.target.value }))
                    }
                    rows={2}
                    className="field mt-2 resize-none"
                  />
                ) : (
                  <input
                    type={field.number ? "number" : "text"}
                    step={field.step}
                    value={form[field.key] ?? ""}
                    onChange={(e) =>
                      setForm((f) => ({
                        ...f,
                        [field.key]:
                          field.key === "admin_password"
                            ? sanitizePassword(e.target.value)
                            : e.target.value,
                      }))
                    }
                    className="field mt-2"
                    dir={field.ltr ? "ltr" : undefined}
                    style={field.ltr ? { textAlign: "right" } : undefined}
                  />
                )}
                {field.hint && (
                  <span className="mt-1.5 block text-[10px] font-normal leading-relaxed text-white/35">
                    {field.hint}
                  </span>
                )}
              </label>
            ))}
          </div>
        </div>
      ))}

      <div className="sticky bottom-4 z-10 flex justify-end">
        <button
          type="submit"
          disabled={busy}
          className="btn-sheen flex items-center gap-2 rounded-2xl bg-gradient-to-l from-lead-600 via-lead-500 to-neonlime px-8 py-3.5 font-display text-sm font-bold text-night-950 shadow-[0_10px_36px_rgba(0,230,118,0.4)] transition active:scale-95 disabled:opacity-50"
        >
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
          حفظ جميع الإعدادات
        </button>
      </div>
    </form>
  );
}