"use client";

import { useEffect, useRef, useState } from "react";
import {
  Check,
  Crown,
  Eye,
  ImagePlus,
  Loader2,
  Save,
  Star,
  Upload,
  X,
} from "lucide-react";
import { RobuxIcon } from "@/components/icons";
import {
  PLATFORM_LABELS,
  PRODUCT_IMAGES,
  type Category,
  type Platform,
  type Product,
} from "@/lib/defaults";

/** يحوّل الملف لصورة مضغوطة data URL عشان تنحفظ بقاعدة البيانات */
function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const max = 900;
        const scale = Math.min(1, max / Math.max(img.width, img.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.max(1, Math.round(img.width * scale));
        canvas.height = Math.max(1, Math.round(img.height * scale));
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          resolve(reader.result as string);
          return;
        }
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL("image/jpeg", 0.85));
      };
      img.onerror = () => reject(new Error("تعذر قراءة الصورة"));
      img.src = reader.result as string;
    };
    reader.onerror = () => reject(new Error("تعذر قراءة الملف"));
    reader.readAsDataURL(file);
  });
}

function ToggleRow({
  checked,
  onChange,
  icon: Icon,
  label,
  hint,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  icon: typeof Eye;
  label: string;
  hint: string;
}) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className={`flex items-center justify-between gap-3 rounded-xl border px-4 py-3 text-right transition ${
        checked
          ? "border-lead-500/40 bg-lead-500/10"
          : "border-white/10 bg-black/30"
      }`}
    >
      <span className="flex items-center gap-2.5">
        <Icon className={`h-4 w-4 ${checked ? "text-lead-400" : "text-white/40"}`} />
        <span>
          <span className="block text-xs font-bold text-white">{label}</span>
          <span className="mt-0.5 block text-[10px] text-white/40">{hint}</span>
        </span>
      </span>
      <span
        className={`relative h-5 w-9 shrink-0 rounded-full transition ${
          checked ? "bg-lead-500" : "bg-white/15"
        }`}
      >
        <span
          className={`absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all ${
            checked ? "right-0.5" : "right-[18px]"
          }`}
        />
      </span>
    </button>
  );
}

export default function ProductForm({
  product,
  onClose,
  onSave,
}: {
  product: Product | null;
  onClose: () => void;
  onSave: (input: Record<string, unknown>, id?: number) => Promise<void>;
}) {
  const [form, setForm] = useState({
    name: product?.name ?? "",
    description: product?.description ?? "",
    category: (product?.category ?? "boost") as Category,
    platform: (product?.platform ?? "roblox") as Platform,
    priceUsd: product?.priceUsd ?? "5",
    unit: product?.unit ?? "لكل 1000",
    robuxPrice: product?.robuxPrice != null ? String(product.robuxPrice) : "",
    premiumOnly: product?.premiumOnly ?? true,
    image: product?.image ?? PRODUCT_IMAGES[0],
    badge: product?.badge ?? "",
    featured: product?.featured ?? false,
    active: product?.active ?? true,
    sortOrder: product?.sortOrder != null ? String(product.sortOrder) : "0",
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [onClose]);

  const set = <K extends keyof typeof form>(key: K, value: (typeof form)[K]) =>
    setForm((f) => ({ ...f, [key]: value }));

  const upload = async (file: File | undefined) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setError("اختر ملف صورة صالح");
      return;
    }
    if (file.size > 8 * 1024 * 1024) {
      setError("حجم الصورة أكبر من 8MB");
      return;
    }
    try {
      const dataUrl = await fileToDataUrl(file);
      set("image", dataUrl);
      setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "تعذر رفع الصورة");
    }
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim()) {
      setError("اسم المنتج مطلوب");
      return;
    }
    setBusy(true);
    setError("");
    try {
      await onSave(
        {
          ...form,
          robuxPrice: form.robuxPrice === "" ? null : Number(form.robuxPrice),
          sortOrder: Number(form.sortOrder) || 0,
        },
        product?.id
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : "تعذر الحفظ");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div
      className="fade-in fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <form
        onSubmit={submit}
        onClick={(e) => e.stopPropagation()}
        className="modal-pop max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-3xl border border-lead-500/25 bg-night-800 shadow-[0_0_80px_rgba(0,230,118,0.15)]"
      >
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-white/8 bg-night-800/95 px-6 py-4 backdrop-blur">
          <h3 className="font-display text-lg font-bold text-white">
            {product ? "تعديل المنتج" : "إضافة منتج جديد"}
          </h3>
          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق"
            className="rounded-full border border-white/10 bg-white/5 p-2 text-white/60 transition hover:rotate-90 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="grid gap-4 p-6 sm:grid-cols-2">
          <label className="block text-xs font-bold text-white/60 sm:col-span-2">
            اسم المنتج *
            <input
              value={form.name}
              onChange={(e) => set("name", e.target.value)}
              className="field mt-2"
              placeholder="مثال: رشق متابعين روبلوكس"
            />
          </label>

          <label className="block text-xs font-bold text-white/60 sm:col-span-2">
            وصف المنتج
            <textarea
              value={form.description}
              onChange={(e) => set("description", e.target.value)}
              rows={2}
              className="field mt-2 resize-none"
              placeholder="وصف مختصر يظهر بالبطاقة…"
            />
          </label>

          <label className="block text-xs font-bold text-white/60">
            القسم
            <select
              value={form.category}
              onChange={(e) => set("category", e.target.value as Category)}
              className="field mt-2 cursor-pointer"
            >
              <option value="boost">قسم الرشق</option>
              <option value="shop">قسم المبيعات</option>
            </select>
          </label>

          <label className="block text-xs font-bold text-white/60">
            المنصة
            <select
              value={form.platform}
              onChange={(e) => set("platform", e.target.value as Platform)}
              className="field mt-2 cursor-pointer"
            >
              {(Object.keys(PLATFORM_LABELS) as Platform[]).map((p) => (
                <option key={p} value={p}>
                  {PLATFORM_LABELS[p]}
                </option>
              ))}
            </select>
          </label>

          <label className="block text-xs font-bold text-white/60">
            السعر بالدولار ($) *
            <input
              type="number"
              min="0"
              step="0.5"
              value={form.priceUsd}
              onChange={(e) => set("priceUsd", e.target.value)}
              className="field mt-2"
              dir="ltr"
              style={{ textAlign: "right" }}
            />
          </label>

          <label className="block text-xs font-bold text-white/60">
            وحدة السعر
            <input
              value={form.unit}
              onChange={(e) => set("unit", e.target.value)}
              className="field mt-2"
              placeholder="لكل 1000 متابع"
            />
          </label>

          <label className="block text-xs font-bold text-white/60">
            <span className="flex items-center gap-1.5">
              <RobuxIcon className="h-3.5 w-3.5 text-neonlime" />
              السعر بالروبوكس (اختياري)
            </span>
            <input
              type="number"
              min="0"
              step="50"
              value={form.robuxPrice}
              onChange={(e) => set("robuxPrice", e.target.value)}
              className="field mt-2"
              placeholder="اتركه فاضي لإخفاء خيار الروبوكس"
              dir="ltr"
              style={{ textAlign: "right" }}
            />
          </label>

          <label className="block text-xs font-bold text-white/60">
            شارة مميزة (اختياري)
            <input
              value={form.badge}
              onChange={(e) => set("badge", e.target.value)}
              className="field mt-2"
              placeholder="الأكثر طلبًا / جديد / حصري"
            />
          </label>

          {/* الصورة */}
          <div className="sm:col-span-2">
            <span className="flex items-center gap-1.5 text-xs font-bold text-white/60">
              <ImagePlus className="h-4 w-4 text-lead-400" />
              صورة المنتج
            </span>
            <div className="mt-2 flex flex-wrap items-start gap-4">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={form.image}
                alt="معاينة صورة المنتج"
                className="h-28 w-28 rounded-2xl border border-lead-500/30 object-cover"
              />
              <div className="flex-1">
                <div className="grid grid-cols-6 gap-2">
                  {PRODUCT_IMAGES.map((img) => (
                    <button
                      key={img}
                      type="button"
                      onClick={() => set("image", img)}
                      className={`relative overflow-hidden rounded-lg border-2 transition ${
                        form.image === img
                          ? "border-lead-500 shadow-[0_0_14px_rgba(0,230,118,0.4)]"
                          : "border-transparent opacity-70 hover:opacity-100"
                      }`}
                    >
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={img} alt="صورة جاهزة" className="aspect-square w-full object-cover" />
                      {form.image === img && (
                        <span className="absolute inset-0 grid place-items-center bg-lead-500/30">
                          <Check className="h-4 w-4 text-white" />
                        </span>
                      )}
                    </button>
                  ))}
                </div>
                <div className="mt-2.5 flex gap-2">
                  <input
                    value={form.image.startsWith("data:") ? "" : form.image}
                    onChange={(e) => set("image", e.target.value)}
                    className="field flex-1 text-xs"
                    placeholder="أو ألصق رابط صورة / مسار…"
                    dir="ltr"
                    style={{ textAlign: "right" }}
                  />
                  <button
                    type="button"
                    onClick={() => fileRef.current?.click()}
                    className="flex shrink-0 items-center gap-1.5 rounded-xl border border-lead-500/40 bg-lead-500/10 px-3.5 text-xs font-bold text-lead-300 transition hover:bg-lead-500/20"
                  >
                    <Upload className="h-3.5 w-3.5" />
                    رفع صورة
                  </button>
                  <input
                    ref={fileRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => upload(e.target.files?.[0])}
                  />
                </div>
                {form.image.startsWith("data:") && (
                  <p className="mt-1.5 text-[10px] font-bold text-lead-400">
                    ✔ صورة مرفوعة من جهازك (مضغوطة تلقائيًا)
                  </p>
                )}
              </div>
            </div>
          </div>

          <ToggleRow
            checked={form.premiumOnly}
            onChange={(v) => set("premiumOnly", v)}
            icon={Crown}
            label="الروبوكس للبريميوم فقط"
            hint="يظهر إطار أخضر لامع مع تنبيه البريميوم"
          />
          <ToggleRow
            checked={form.featured}
            onChange={(v) => set("featured", v)}
            icon={Star}
            label="منتج مميز"
            hint="إطار أخضر متوهج يبرز البطاقة"
          />
          <ToggleRow
            checked={form.active}
            onChange={(v) => set("active", v)}
            icon={Eye}
            label="ظاهر في المتجر"
            hint="أوقفه لإخفاء المنتج مؤقتًا"
          />
          <label className="block text-xs font-bold text-white/60">
            ترتيب الظهور (الأصغر أولًا)
            <input
              type="number"
              value={form.sortOrder}
              onChange={(e) => set("sortOrder", e.target.value)}
              className="field mt-2"
              dir="ltr"
              style={{ textAlign: "right" }}
            />
          </label>

          {error && (
            <div className="rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-xs font-bold text-red-300 sm:col-span-2">
              {error}
            </div>
          )}
        </div>

        <div className="sticky bottom-0 flex items-center justify-end gap-2 border-t border-white/8 bg-night-800/95 px-6 py-4 backdrop-blur">
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl border border-white/10 px-5 py-2.5 text-sm font-bold text-white/60 transition hover:text-white"
          >
            إلغاء
          </button>
          <button
            type="submit"
            disabled={busy}
            className="btn-sheen flex items-center gap-2 rounded-xl bg-gradient-to-l from-lead-600 to-lead-500 px-6 py-2.5 text-sm font-bold text-night-950 transition active:scale-95 disabled:opacity-50"
          >
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
            {product ? "حفظ التعديلات" : "إضافة المنتج"}
          </button>
        </div>
      </form>
    </div>
  );
}