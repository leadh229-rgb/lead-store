"use client";

import { Rocket, ShoppingBag, Sparkles } from "lucide-react";
import type { Product, SettingsMap } from "@/lib/defaults";
import StoreProvider from "./site/StoreProvider";
import Header from "./site/Header";
import Hero from "./site/Hero";
import ProductCard from "./site/ProductCard";
import Reveal from "./site/Reveal";
import {
  CtaBanner,
  Faq,
  Footer,
  HowItWorks,
  Marquee,
  SectionHeading,
} from "./site/Sections";

function EmptyNote() {
  return (
    <div className="col-span-full rounded-3xl border border-dashed border-lead-500/25 bg-lead-500/[0.03] px-6 py-14 text-center">
      <Sparkles className="mx-auto h-8 w-8 text-lead-400" />
      <p className="mt-3 font-display text-lg font-bold text-white/70">
        قريبًا خدمات جديدة بهذا القسم
      </p>
      <p className="mt-1 text-sm text-white/40">ترقبوا عروض ليد القادمة 🔥</p>
    </div>
  );
}

export default function StoreClient({
  products,
  settings,
}: {
  products: Product[];
  settings: SettingsMap;
}) {
  const boost = products.filter((p) => p.category === "boost");
  const shop = products.filter((p) => p.category === "shop");

  return (
    <StoreProvider settings={settings}>
      {/* طبقة الحبيبات */}
      <div className="noise pointer-events-none fixed inset-0 z-[45] opacity-[0.035]" />

      <Header />

      <main>
        <Hero products={products} />
        <Marquee />

        {/* قسم الرشق */}
        <section id="boost" className="relative mx-auto max-w-7xl scroll-mt-24 px-4 py-20 sm:px-6">
          <div className="pointer-events-none absolute left-0 top-24 h-72 w-72 rounded-full bg-lead-600/10 blur-[110px]" />
          <SectionHeading
            icon={Rocket}
            title={settings.boost_title}
            subtitle={settings.boost_subtitle}
          />
          <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
            {boost.length === 0 && <EmptyNote />}
            {boost.map((product, i) => (
              <Reveal key={product.id} delay={i * 90} className="h-full">
                <ProductCard product={product} />
              </Reveal>
            ))}
          </div>
        </section>

        {/* قسم المبيعات */}
        <section id="shop" className="relative scroll-mt-24 border-y border-lead-500/10 bg-night-800/40 py-20">
          <div className="pointer-events-none absolute right-[10%] top-10 h-64 w-64 rounded-full bg-blurple/10 blur-[110px]" />
          <div className="relative mx-auto max-w-7xl px-4 sm:px-6">
            <SectionHeading
              icon={ShoppingBag}
              title={settings.shop_title}
              subtitle={settings.shop_subtitle}
            />
            <div className="grid gap-6 lg:grid-cols-2">
              {shop.length === 0 && <EmptyNote />}
              {shop.map((product, i) => (
                <Reveal key={product.id} delay={i * 110} className="h-full">
                  <ProductCard product={product} wide />
                </Reveal>
              ))}
            </div>
          </div>
        </section>

        <HowItWorks />
        <Faq />
        <CtaBanner />
      </main>

      <Footer />
    </StoreProvider>
  );
}