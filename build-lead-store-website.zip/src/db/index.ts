import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";

const databaseUrl = process.env.DATABASE_URL;

// عند النشر على منصات مثل Vercel/Railway قد لا تكون DATABASE_URL متاحة وقت البناء،
// لذلك نكتفي بتحذير بدل التوقف — ويظهر المتجر بالبيانات الاحتياطية حتى يتم ضبطها.
if (!databaseUrl) {
  console.warn(
    "[db] DATABASE_URL not set — the database is unavailable until configured (fallback data will be shown)."
  );
}

const globalForDb = globalThis as typeof globalThis & {
  __arenaNextJsPostgresqlPool?: Pool;
};

export const pool =
  globalForDb.__arenaNextJsPostgresqlPool ??
  new Pool({
    connectionString: databaseUrl,
  });

if (process.env.NODE_ENV !== "production") {
  globalForDb.__arenaNextJsPostgresqlPool = pool;
}

export const db = drizzle(pool);
