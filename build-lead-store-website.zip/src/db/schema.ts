import {
  pgTable,
  serial,
  text,
  integer,
  boolean,
  numeric,
  timestamp,
} from "drizzle-orm/pg-core";

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull().default(""),
  // boost = قسم الرشق | shop = قسم المبيعات
  category: text("category").notNull().default("boost"),
  // roblox | twitter | kick | discord
  platform: text("platform").notNull().default("roblox"),
  priceUsd: numeric("price_usd", { precision: 10, scale: 2 })
    .notNull()
    .default("0"),
  unit: text("unit").notNull().default(""),
  robuxPrice: integer("robux_price"),
  premiumOnly: boolean("premium_only").notNull().default(true),
  image: text("image").notNull().default(""),
  badge: text("badge"),
  featured: boolean("featured").notNull().default(false),
  active: boolean("active").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const settings = pgTable("settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull().default(""),
});

export type ProductRow = typeof products.$inferSelect;
export type SettingRow = typeof settings.$inferSelect;