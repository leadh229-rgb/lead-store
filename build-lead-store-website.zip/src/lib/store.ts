import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { products, settings, type ProductRow } from "@/db/schema";
import {
  DEFAULT_PRODUCTS,
  DEFAULT_SETTINGS,
  type Category,
  type Platform,
  type Product,
  type SettingsMap,
} from "./defaults";

let seeded = false;

/** يزرع البيانات الافتراضية عند أول تشغيل فقط */
export async function ensureSeeded(): Promise<void> {
  if (seeded) return;
  const existingProducts = await db
    .select({ id: products.id })
    .from(products)
    .limit(1);
  if (existingProducts.length === 0) {
    await db.insert(products).values(
      DEFAULT_PRODUCTS.map((p) => ({
        name: p.name,
        description: p.description,
        category: p.category,
        platform: p.platform,
        priceUsd: p.priceUsd,
        unit: p.unit,
        robuxPrice: p.robuxPrice,
        premiumOnly: p.premiumOnly,
        image: p.image,
        badge: p.badge,
        featured: p.featured,
        active: p.active,
        sortOrder: p.sortOrder,
      }))
    );
  }
  const existingSettings = await db
    .select({ key: settings.key })
    .from(settings)
    .limit(1);
  if (existingSettings.length === 0) {
    await db
      .insert(settings)
      .values(
        Object.entries(DEFAULT_SETTINGS).map(([key, value]) => ({ key, value }))
      );
  }
  seeded = true;
}

export function toProduct(row: ProductRow): Product {
  return {
    id: row.id,
    name: row.name,
    description: row.description,
    category: (row.category === "shop" ? "shop" : "boost") as Category,
    platform: (
      ["roblox", "twitter", "kick", "discord", "twitch"].includes(row.platform)
        ? row.platform
        : "roblox"
    ) as Platform,
    priceUsd: row.priceUsd,
    unit: row.unit,
    robuxPrice: row.robuxPrice,
    premiumOnly: row.premiumOnly,
    image: row.image,
    badge: row.badge,
    featured: row.featured,
    active: row.active,
    sortOrder: row.sortOrder,
  };
}

/** المنتجات الظاهرة للزوار — مع بديل آمن لو قاعدة البيانات غير جاهزة */
export async function getPublicProducts(): Promise<Product[]> {
  try {
    await ensureSeeded();
    const rows = await db
      .select()
      .from(products)
      .where(eq(products.active, true))
      .orderBy(asc(products.sortOrder), asc(products.id));
    return rows.map(toProduct);
  } catch (error) {
    console.error("getPublicProducts fallback:", error);
    return DEFAULT_PRODUCTS.filter((p) => p.active);
  }
}

export async function getAllProducts(): Promise<Product[]> {
  await ensureSeeded();
  const rows = await db
    .select()
    .from(products)
    .orderBy(asc(products.sortOrder), asc(products.id));
  return rows.map(toProduct);
}

export async function getSettingsMap(): Promise<SettingsMap> {
  try {
    await ensureSeeded();
    const rows = await db.select().from(settings);
    const map: SettingsMap = { ...DEFAULT_SETTINGS };
    for (const row of rows) map[row.key] = row.value;
    return map;
  } catch (error) {
    console.error("getSettingsMap fallback:", error);
    return { ...DEFAULT_SETTINGS };
  }
}

/** إعدادات عامة بدون كلمة سر لوحة التحكم */
export async function getPublicSettings(): Promise<SettingsMap> {
  const all = await getSettingsMap();
  const { admin_password: _hidden, ...pub } = all;
  return pub;
}

export async function saveSettings(map: SettingsMap): Promise<void> {
  await ensureSeeded();
  for (const [key, value] of Object.entries(map)) {
    await db
      .insert(settings)
      .values({ key, value: String(value) })
      .onConflictDoUpdate({ target: settings.key, set: { value: String(value) } });
  }
}