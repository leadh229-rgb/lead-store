const TOKEN_KEY = "lead_admin_token";

/**
 * التوكن بالذاكرة أولًا — يشتغل حتى لو المتصفح يمنع التخزين والكوكيز
 * بالكامل داخل إطار المعاينة، والتخزين المحلي مجرد نسخة احتياطية
 * لبقاء الجلسة بعد تحديث الصفحة.
 */
let memoryToken: string | null = null;

export function getAdminToken(): string | null {
  if (memoryToken) return memoryToken;
  try {
    memoryToken = window.localStorage.getItem(TOKEN_KEY);
  } catch {
    /* التخزين محجوب — نكتفي بالذاكرة */
  }
  return memoryToken;
}

export function setAdminToken(token: string): void {
  memoryToken = token;
  try {
    window.localStorage.setItem(TOKEN_KEY, token);
  } catch {
    /* التخزين محجوب — الذاكرة تكفي */
  }
}

export function clearAdminToken(): void {
  memoryToken = null;
  try {
    window.localStorage.removeItem(TOKEN_KEY);
  } catch {
    /* التخزين محجوب */
  }
}

/** ترويسة المصادقة لكل طلبات لوحة التحكم */
export function adminAuthHeaders(): Record<string, string> {
  const token = getAdminToken();
  return token ? { Authorization: `Bearer ${token}` } : {};
}