/**
 * ينظف كلمة السر من الأحرف غير المرئية اللي تنحقن تلقائيًا عند النسخ
 * من نصوص عربية (علامات الاتجاه RTL/LRM، المسافات الصفرية، BOM…)
 * ثم يشيل المسافات الزائدة من الأطراف.
 */
const INVISIBLE_CHARS =
  /[\u200B-\u200F\u202A-\u202E\u2066-\u2069\uFEFF\u061C]/g;

export function sanitizePassword(input: string): string {
  return input.replace(INVISIBLE_CHARS, "").trim();
}