import type { Category, Platform } from "./defaults";

export interface ProductInput {
  name: string;
  description: string;
  category: Category;
  platform: Platform;
  priceUsd: string;
  unit: string;
  robuxPrice: number | null;
  premiumOnly: boolean;
  image: string;
  badge: string | null;
  featured: boolean;
  active: boolean;
  sortOrder: number;
}

function str(v: unknown, fallback = ""): string {
  return typeof v === "string" ? v.trim() : fallback;
}

function bool(v: unknown, fallback = false): boolean {
  return typeof v === "boolean" ? v : fallback;
}

/** يتحقق من مدخلات المنتج ويرمي خطأ برسالة عربية عند الخلل */
export function parseProductInput(body: unknown): ProductInput {
  if (typeof body !== "object" || body === null) {
    throw new Error("بيانات غير صالحة");
  }
  const b = body as Record<string, unknown>;
  const name = str(b.name);
  if (!name) throw new Error("اسم المنتج مطلوب");

  const price = Number(b.priceUsd);
  if (!Number.isFinite(price) || price < 0) throw new Error("سعر الدولار غير صالح");

  let robux: number | null = null;
  if (b.robuxPrice !== null && b.robuxPrice !== undefined && b.robuxPrice !== "") {
    const r = Number(b.robuxPrice);
    if (!Number.isFinite(r) || r < 0) throw new Error("سعر الروبوكس غير صالح");
    robux = Math.round(r);
  }

  const category: Category = b.category === "shop" ? "shop" : "boost";
  const platform: Platform = (
    ["roblox", "twitter", "kick", "discord", "twitch"] as const
  ).includes(b.platform as Platform)
    ? (b.platform as Platform)
    : "roblox";

  const image = str(b.image, "/images/products/roblox-followers.jpg");
  if (image.length > 3_000_000) throw new Error("حجم الصورة كبير جدًا");

  return {
    name,
    description: str(b.description),
    category,
    platform,
    priceUsd: price.toFixed(2),
    unit: str(b.unit),
    robuxPrice: robux,
    premiumOnly: bool(b.premiumOnly, true),
    image,
    badge: str(b.badge) || null,
    featured: bool(b.featured),
    active: bool(b.active, true),
    sortOrder: Number.isFinite(Number(b.sortOrder)) ? Math.round(Number(b.sortOrder)) : 0,
  };
}