export type Category = "boost" | "shop";
export type Platform = "roblox" | "twitter" | "kick" | "discord" | "twitch";

export interface Product {
  id: number;
  name: string;
  description: string;
  category: Category;
  platform: Platform;
  priceUsd: string;
  unit: string;
  robuxPrice: number | null;
  premiumOnly: boolean;
  image: string;
  badge: string | null;
  featured: boolean;
  active: boolean;
  sortOrder: number;
}

export type SettingsMap = Record<string, string>;

export const PRODUCT_IMAGES = [
  "/images/products/roblox-followers.jpg",
  "/images/products/roblox-groups.jpg",
  "/images/products/roblox-map-favorites.jpg",
  "/images/products/twitter-likes.jpg",
  "/images/products/kick-likes.jpg",
  "/images/products/discord-nitro.jpg",
  "/images/products/discord-effects.jpg",
  "/images/products/twitch-followers.jpg",
  "/images/products/kick-followers.jpg",
  "/images/products/live-views.jpg",
];

export const PLATFORM_LABELS: Record<Platform, string> = {
  roblox: "روبلوكس",
  twitter: "تويتر X",
  kick: "كيك Kick",
  discord: "ديسكورد",
  twitch: "تويتش",
};

export const DEFAULT_SETTINGS: SettingsMap = {
  store_name: "LEAD STORE",
  announcement:
    "كل 1000 متابع روبلوكس بـ 5$ فقط — أو 500 روبوكس لأصحاب البريميوم — وخصم الكميات: 2000 بـ 7$",
  hero_title: "قوّي حسابك وسيطر على اللعبة",
  hero_subtitle:
    "متجر ليد وجهتك الأولى للرشق والخدمات الرقمية: متابعين روبلوكس وتويتش وكيك، فافي الماب وأعضاء القروبات، مشاهدين بث حي، لايكات، نيترو وإفكتات ديسكورد — تسليم سريع وضمان حقيقي.",
  boost_title: "قسم الرشق",
  boost_subtitle: "زِد أرقامك بسرعة وأمان، اختر خدمتك واضغط اطلب الآن",
  shop_title: "قسم المبيعات",
  shop_subtitle: "نيترو ديسكورد وإفكتات حصرية بأفضل الأسعار",
  premium_note: "الدفع بالروبوكس متاح حصريًا لأصحاب البريميوم",
  whatsapp: "212664562982",
  whatsapp_display: "+212 0664562982",
  discord_url: "https://discord.gg/48maQgKRFF",
  stat_orders: "137",
  stat_clients: "210",
  stat_rating: "4.8",
  footer_text:
    "متجر ليد — وجهتك الأولى لخدمات الألعاب والتواصل الاجتماعي. جودة، سرعة، وضمان.",
  admin_password: "Leadhcomatore772_uj",
};

export const DEFAULT_PRODUCTS: Product[] = [
  {
    id: 1,
    name: "رشق متابعين روبلوكس",
    description:
      "زد متابعين حسابك في روبلوكس بسرعة وأمان. خصم الكميات: 2000 متابع بـ 7$ فقط — ضمان تعويض النقصان.",
    category: "boost",
    platform: "roblox",
    priceUsd: "5",
    unit: "لكل 1000 متابع",
    robuxPrice: 500,
    premiumOnly: true,
    image: "/images/products/roblox-followers.jpg",
    badge: "الأكثر طلبًا",
    featured: true,
    active: true,
    sortOrder: 1,
  },
  {
    id: 2,
    name: "رشق أعضاء قروبات روبلوكس",
    description:
      "كبّر قروبك في روبلوكس بأعضاء حقيقيي المظهر، وصول سريع يرفع ترتيب قروبك في البحث — أقل طلب 1000 عضو.",
    category: "boost",
    platform: "roblox",
    priceUsd: "5",
    unit: "لكل 1000 عضو — أقل طلب 1000",
    robuxPrice: 500,
    premiumOnly: true,
    image: "/images/products/roblox-groups.jpg",
    badge: "تسليم سريع",
    featured: false,
    active: true,
    sortOrder: 2,
  },
  {
    id: 7,
    name: "رشق فافي ماب روبلوكس",
    description:
      "رفع مابك لقوائم المفضلة (Favorites) وعدد كبير من الحفظ يوصلك من كل مكان — أقل طلب 1000 فافي.",
    category: "boost",
    platform: "roblox",
    priceUsd: "5",
    unit: "لكل 1000 فافي — أقل طلب 1000",
    robuxPrice: 500,
    premiumOnly: true,
    image: "/images/products/roblox-map-favorites.jpg",
    badge: "جديد",
    featured: false,
    active: true,
    sortOrder: 3,
  },
  {
    id: 3,
    name: "رشق لايكات تويتر (X)",
    description:
      "لايكات قوية لتغريداتك ترفع التفاعل والوصول، تنفيذ فوري على أي تغريدة تختارها.",
    category: "boost",
    platform: "twitter",
    priceUsd: "2",
    unit: "لكل 1000 لايك",
    robuxPrice: 200,
    premiumOnly: true,
    image: "/images/products/twitter-likes.jpg",
    badge: null,
    featured: false,
    active: true,
    sortOrder: 4,
  },
  {
    id: 8,
    name: "رشق متابعين تويتش",
    description:
      "متابعين لقناتك في تويتش بكميات كبيرة. خصم الكميات: 2000 متابع بـ 7$ فقط.",
    category: "boost",
    platform: "twitch",
    priceUsd: "5",
    unit: "لكل 1000 متابع",
    robuxPrice: 500,
    premiumOnly: true,
    image: "/images/products/twitch-followers.jpg",
    badge: "خصم الكميات",
    featured: false,
    active: true,
    sortOrder: 5,
  },
  {
    id: 9,
    name: "رشق متابعين كيك",
    description:
      "متابعين لقناتك في كيك بنفس الأسعار. خصم الكميات: 2000 متابع بـ 7$ فقط.",
    category: "boost",
    platform: "kick",
    priceUsd: "5",
    unit: "لكل 1000 متابع",
    robuxPrice: 500,
    premiumOnly: true,
    image: "/images/products/kick-followers.jpg",
    badge: "خصم الكميات",
    featured: false,
    active: true,
    sortOrder: 6,
  },
  {
    id: 10,
    name: "رشق مشاهدين بث تويتش (Live)",
    description:
      "مشاهدين بث حي لقناتك في تويتش يرفعون التفاعل والانتشار ويظهروك كقناة نشطة.",
    category: "boost",
    platform: "twitch",
    priceUsd: "5",
    unit: "لكل 200 مشاهد",
    robuxPrice: null,
    premiumOnly: true,
    image: "/images/products/live-views.jpg",
    badge: "للبث الحي",
    featured: false,
    active: true,
    sortOrder: 7,
  },
  {
    id: 11,
    name: "رشق مشاهدين بث كيك (Live)",
    description:
      "مشاهدين بث حي لقناتك في كيك يرفعون التفاعل والانتشار ويظهروك كقناة نشطة.",
    category: "boost",
    platform: "kick",
    priceUsd: "5",
    unit: "لكل 200 مشاهد",
    robuxPrice: null,
    premiumOnly: true,
    image: "/images/products/live-views.jpg",
    badge: "للبث الحي",
    featured: false,
    active: true,
    sortOrder: 8,
  },
  {
    id: 12,
    name: "لايكات مقاطع تويتش (VOD)",
    description:
      "لايكات لمقاطع البث المسجلة (VODs) — خدمة لتويتش فقط، ترفع تفاعل مقاطعك وقناة.",
    category: "boost",
    platform: "twitch",
    priceUsd: "5",
    unit: "لكل 3000 لايك",
    robuxPrice: null,
    premiumOnly: true,
    image: "/images/products/twitter-likes.jpg",
    badge: "تويتش فقط",
    featured: false,
    active: true,
    sortOrder: 9,
  },
  {
    id: 4,
    name: "رشق لايكات كيك (Kick)",
    description:
      "عزّز تفاعل قناتك في كيك بلايكات تلفت الأنظار لبثوثك ومقاطعك.",
    category: "boost",
    platform: "kick",
    priceUsd: "3",
    unit: "لكل 1000 لايك",
    robuxPrice: 300,
    premiumOnly: true,
    image: "/images/products/kick-likes.jpg",
    badge: "جديد",
    featured: false,
    active: true,
    sortOrder: 10,
  },
  {
    id: 5,
    name: "نيترو ديسكورد — شهر",
    description:
      "نيترو كامل لمدة شهر: بث بجودة عالية، رفع ملفات أضخم، إيموجي متحرك والمزيد. تفعيل مباشر على حسابك.",
    category: "shop",
    platform: "discord",
    priceUsd: "6",
    unit: "اشتراك شهر كامل",
    robuxPrice: 600,
    premiumOnly: true,
    image: "/images/products/discord-nitro.jpg",
    badge: "تفعيل فوري",
    featured: true,
    active: true,
    sortOrder: 11,
  },
  {
    id: 6,
    name: "إفكتات ديسكورد",
    description:
      "إطارات وإفكتات أفاتار حصرية تميّز بروفايلك عن الكل، تُسلّم كهدية مباشرة على حسابك.",
    category: "shop",
    platform: "discord",
    priceUsd: "3",
    unit: "للإفكت الواحد",
    robuxPrice: 300,
    premiumOnly: true,
    image: "/images/products/discord-effects.jpg",
    badge: "حصري",
    featured: false,
    active: true,
    sortOrder: 12,
  },
];