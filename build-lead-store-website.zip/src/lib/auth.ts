import { createHmac, timingSafeEqual } from "crypto";
import { cookies, headers } from "next/headers";
import { getSettingsMap } from "./store";

export const ADMIN_COOKIE = "lead_admin_session";

export function sessionToken(password: string): string {
  return createHmac("sha256", `lead-store-v1::${password}`)
    .update("lead-admin-session")
    .digest("hex");
}

export async function currentPassword(): Promise<string> {
  const map = await getSettingsMap();
  return map.admin_password || process.env.ADMIN_PASSWORD || "Leadhcomatore772_uj";
}

function safeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  try {
    return timingSafeEqual(Buffer.from(a, "utf8"), Buffer.from(b, "utf8"));
  } catch {
    return false;
  }
}

/**
 * يتحقق من الجلسة عبر ترويسة Authorization (تعمل حتى لو المتصفح حاجب الكوكيز
 * داخل إطار المعاينة) أو عبر الكوكي التقليدية.
 */
export async function isAdmin(): Promise<boolean> {
  try {
    const expected = sessionToken(await currentPassword());

    const hdrs = await headers();
    const auth = hdrs.get("authorization");
    if (auth && auth.startsWith("Bearer ")) {
      const token = auth.slice(7).trim();
      if (token && safeEqual(token, expected)) return true;
    }

    const jar = await cookies();
    const value = jar.get(ADMIN_COOKIE)?.value;
    if (value && safeEqual(value, expected)) return true;

    return false;
  } catch {
    return false;
  }
}

export async function unauthorized(): Promise<Response> {
  return Response.json({ error: "غير مصرح — سجل الدخول أولًا" }, { status: 401 });
}