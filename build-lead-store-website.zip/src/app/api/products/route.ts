import { getPublicProducts } from "@/lib/store";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const category = searchParams.get("category");
  let items = await getPublicProducts();
  if (category === "boost" || category === "shop") {
    items = items.filter((p) => p.category === category);
  }
  return Response.json({ products: items });
}