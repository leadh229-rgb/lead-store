import { getPublicSettings } from "@/lib/store";

export const dynamic = "force-dynamic";

export async function GET() {
  const map = await getPublicSettings();
  return Response.json({ settings: map });
}