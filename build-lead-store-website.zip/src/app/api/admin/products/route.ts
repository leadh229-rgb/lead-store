import { db } from "@/db";
import { products } from "@/db/schema";
import { isAdmin, unauthorized } from "@/lib/auth";
import { parseProductInput } from "@/lib/productInput";
import { getAllProducts, toProduct } from "@/lib/store";

export const dynamic = "force-dynamic";

export async function GET() {
  if (!(await isAdmin())) return unauthorized();
  const items = await getAllProducts();
  return Response.json({ products: items });
}

export async function POST(request: Request) {
  if (!(await isAdmin())) return unauthorized();
  try {
    const input = parseProductInput(await request.json());
    const [row] = await db.insert(products).values(input).returning();
    return Response.json({ product: toProduct(row) });
  } catch (error) {
    const message = error instanceof Error ? error.message : "تعذر حفظ المنتج";
    return Response.json({ error: message }, { status: 400 });
  }
}