import { eq } from "drizzle-orm";
import { db } from "@/db";
import { products } from "@/db/schema";
import { isAdmin, unauthorized } from "@/lib/auth";
import { parseProductInput } from "@/lib/productInput";
import { toProduct } from "@/lib/store";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function PUT(request: Request, ctx: Ctx) {
  if (!(await isAdmin())) return unauthorized();
  const { id } = await ctx.params;
  const productId = Number(id);
  if (!Number.isInteger(productId)) {
    return Response.json({ error: "معرّف غير صالح" }, { status: 400 });
  }
  try {
    const body = (await request.json()) as Record<string, unknown>;
    // تحديث جزئي (مثل تبديل التفعيل) أو كامل
    if (Object.keys(body).length === 1 && typeof body.active === "boolean") {
      const [row] = await db
        .update(products)
        .set({ active: body.active })
        .where(eq(products.id, productId))
        .returning();
      if (!row) return Response.json({ error: "المنتج غير موجود" }, { status: 404 });
      return Response.json({ product: toProduct(row) });
    }
    const input = parseProductInput(body);
    const [row] = await db
      .update(products)
      .set(input)
      .where(eq(products.id, productId))
      .returning();
    if (!row) return Response.json({ error: "المنتج غير موجود" }, { status: 404 });
    return Response.json({ product: toProduct(row) });
  } catch (error) {
    const message = error instanceof Error ? error.message : "تعذر تحديث المنتج";
    return Response.json({ error: message }, { status: 400 });
  }
}

export async function DELETE(_request: Request, ctx: Ctx) {
  if (!(await isAdmin())) return unauthorized();
  const { id } = await ctx.params;
  const productId = Number(id);
  if (!Number.isInteger(productId)) {
    return Response.json({ error: "معرّف غير صالح" }, { status: 400 });
  }
  const [row] = await db
    .delete(products)
    .where(eq(products.id, productId))
    .returning({ id: products.id });
  if (!row) return Response.json({ error: "المنتج غير موجود" }, { status: 404 });
  return Response.json({ ok: true });
}