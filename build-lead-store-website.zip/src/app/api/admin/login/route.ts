import { cookies } from "next/headers";
import { ADMIN_COOKIE, currentPassword, sessionToken } from "@/lib/auth";
import { sanitizePassword } from "@/lib/sanitize";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as { password?: string };
    // نشيل الأحرف غير المرئية (علامات الاتجاه من النسخ العربي) والمسافات الزائدة
    const password =
      typeof body.password === "string" ? sanitizePassword(body.password) : "";
    const expected = await currentPassword();
    if (!password || password !== expected) {
      return Response.json(
        { error: "كلمة السر غير صحيحة — انتبه للأحرف الكبيرة والصغيرة والرموز" },
        { status: 401 }
      );
    }
    const token = sessionToken(expected);
    const jar = await cookies();
    // SameSite=None + Secure عشان تشتغل داخل إطار المعاينة، ومعاها توكن احتياطي
    jar.set(ADMIN_COOKIE, token, {
      httpOnly: true,
      sameSite: "none",
      secure: true,
      path: "/",
      maxAge: 60 * 60 * 24 * 7,
    });
    return Response.json({ ok: true, token });
  } catch {
    return Response.json({ error: "طلب غير صالح" }, { status: 400 });
  }
}