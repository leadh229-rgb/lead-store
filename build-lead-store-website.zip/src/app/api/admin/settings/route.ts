import { isAdmin, unauthorized } from "@/lib/auth";
import { sanitizePassword } from "@/lib/sanitize";
import { getSettingsMap, saveSettings } from "@/lib/store";
import type { SettingsMap } from "@/lib/defaults";

export const dynamic = "force-dynamic";

export async function GET() {
  if (!(await isAdmin())) return unauthorized();
  const map = await getSettingsMap();
  return Response.json({ settings: map });
}

export async function PUT(request: Request) {
  if (!(await isAdmin())) return unauthorized();
  try {
    const body = (await request.json()) as { settings?: Record<string, unknown> };
    if (!body.settings || typeof body.settings !== "object") {
      return Response.json({ error: "بيانات غير صالحة" }, { status: 400 });
    }
    const clean: SettingsMap = {};
    for (const [key, value] of Object.entries(body.settings)) {
      if (/^[a-z0-9_]{1,60}$/.test(key) && typeof value === "string") {
        clean[key] = value.slice(0, 5000);
      }
    }
    if (clean.admin_password !== undefined) {
      clean.admin_password = sanitizePassword(clean.admin_password);
    }
    if (clean.admin_password !== undefined && clean.admin_password.length < 4) {
      return Response.json(
        { error: "كلمة السر الجديدة قصيرة جدًا (4 أحرف على الأقل)" },
        { status: 400 }
      );
    }
    await saveSettings(clean);
    return Response.json({ ok: true });
  } catch {
    return Response.json({ error: "تعذر حفظ الإعدادات" }, { status: 400 });
  }
}