"use client";

import { useCallback, useEffect, useState } from "react";
import { AlertTriangle, Eye, EyeOff, KeyRound, Loader2, ShieldAlert, Zap } from "lucide-react";
import AdminDashboard from "@/components/admin/AdminDashboard";
import { adminAuthHeaders, setAdminToken } from "@/lib/adminClient";
import { sanitizePassword } from "@/lib/sanitize";

type Status = "loading" | "guest" | "authed";

function LoginScreen({ onSuccess }: { onSuccess: () => void }) {
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [capsOn, setCapsOn] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const checkCaps = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (typeof e.getModifierState === "function") {
      setCapsOn(e.getModifierState("CapsLock"));
    }
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password: sanitizePassword(password) }),
        cache: "no-store",
      });
      const data = (await res.json()) as { error?: string; token?: string };
      if (!res.ok) throw new Error(data.error || "تعذر تسجيل الدخول");
      // نحفظ توكن الجلسة محليًا — يشتغل حتى لو المتصفح حاجب الكوكيز
      if (data.token) setAdminToken(data.token);
      onSuccess();
    } catch (err) {
      setError(err instanceof Error ? err.message : "تعذر تسجيل الدخول");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden px-4">
      <div className="bg-grid absolute inset-0" />
      <div className="pointer-events-none absolute -top-24 left-1/2 h-80 w-80 -translate-x-1/2 rounded-full bg-lead-600/20 blur-[120px]" />
      <form
        onSubmit={submit}
        className="modal-pop relative w-full max-w-sm rounded-3xl border border-lead-500/25 bg-night-800/90 p-8 shadow-[0_0_70px_rgba(0,230,118,0.12)] backdrop-blur"
      >
        <div className="flex flex-col items-center text-center">
          <span className="grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-neonlime via-lead-500 to-lead-700 text-night-950 shadow-[0_0_30px_rgba(0,230,118,0.45)]">
            <Zap className="h-7 w-7" strokeWidth={2.5} />
          </span>
          <h1 className="mt-4 font-brand text-xl font-extrabold text-gradient">
            LEAD STORE
          </h1>
          <p className="mt-1 font-display text-lg font-bold text-white">لوحة التحكم</p>
          <p className="mt-1 text-xs text-white/45">
            أدخل كلمة السر للوصول لإدارة المتجر
          </p>
        </div>

        <label className="mt-6 block text-xs font-bold text-white/60">
          كلمة السر
          <div className="relative mt-2">
            <KeyRound className="absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-lead-400" />
            <input
              type={showPassword ? "text" : "password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyDown={checkCaps}
              onKeyUp={checkCaps}
              className="field pl-11 pr-10 font-mono"
              placeholder="••••••••"
              autoFocus
              dir="ltr"
              style={{ textAlign: "left" }}
              autoComplete="current-password"
              autoCapitalize="none"
              autoCorrect="off"
              spellCheck={false}
            />
            <button
              type="button"
              onClick={() => setShowPassword((v) => !v)}
              aria-label={showPassword ? "إخفاء كلمة السر" : "إظهار كلمة السر"}
              title={showPassword ? "إخفاء كلمة السر" : "إظهار كلمة السر"}
              className="absolute left-2 top-1/2 grid h-7 w-7 -translate-y-1/2 place-items-center rounded-lg text-white/45 transition hover:bg-white/10 hover:text-lead-300"
            >
              {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
          <span className="mt-1.5 block text-[10px] font-normal text-white/35">
            اضغط 👁 عشان تشوف الكلمة وتتأكد من الأحرف قبل الدخول
          </span>
          {capsOn && (
            <span className="fade-in mt-2 flex items-center gap-1.5 rounded-lg border border-amber-500/30 bg-amber-500/10 px-3 py-2 text-[10px] font-bold text-amber-300">
              <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
              تنبيه: زر Caps Lock مفعّل — الأحرف بتطلع كبيرة!
            </span>
          )}
        </label>

        {error && (
          <div className="shake mt-3 flex items-center gap-2 rounded-xl border border-red-500/30 bg-red-500/10 px-3.5 py-2.5 text-xs font-bold text-red-300">
            <ShieldAlert className="h-4 w-4 shrink-0" />
            {error}
          </div>
        )}

        <button
          type="submit"
          disabled={busy || !sanitizePassword(password)}
          className="btn-sheen mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-l from-lead-600 to-lead-500 py-3 font-display text-sm font-bold text-night-950 transition active:scale-95 disabled:opacity-50"
        >
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <KeyRound className="h-4 w-4" />}
          دخول
        </button>

        <p className="mt-4 text-center text-[10px] leading-relaxed text-white/30">
          🔒 منطقة محمية — الدخول لمالك المتجر فقط
          <br />
          تقدر تغيّر كلمة السر من تبويب الإعدادات بعد الدخول
        </p>
        <a
          href="/"
          className="mt-3 block text-center text-xs font-bold text-lead-400 transition hover:text-lead-300"
        >
          ← العودة للمتجر
        </a>
      </form>
    </div>
  );
}

export default function AdminPage() {
  const [status, setStatus] = useState<Status>("loading");

  useEffect(() => {
    let cancelled = false;
    fetch("/api/admin/products", { headers: adminAuthHeaders(), cache: "no-store" })
      .then((res) => {
        if (!cancelled) setStatus(res.ok ? "authed" : "guest");
      })
      .catch(() => {
        if (!cancelled) setStatus("guest");
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const logout = useCallback(() => setStatus("guest"), []);

  if (status === "loading") {
    return (
      <div className="grid min-h-screen place-items-center">
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="h-8 w-8 animate-spin text-lead-500" />
          <p className="text-sm font-bold text-white/50">جاري التحقق من الجلسة…</p>
        </div>
      </div>
    );
  }

  if (status === "guest") {
    return <LoginScreen onSuccess={() => setStatus("authed")} />;
  }

  return <AdminDashboard onLogout={logout} />;
}