import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "LEAD STORE | متجر ليد — رشق وخدمات رقمية",
  description:
    "متجر ليد الأول لرشق متابعين روبلوكس، أعضاء القروبات، لايكات تويتر وكيك، وبيع نيترو وإفكتات ديسكورد. تسليم سريع ودفع بالدولار أو الروبوكس لأصحاب البريميوم.",
  icons: { icon: "/icon.svg" },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Changa:wght@400;500;600;700;800&family=Tajawal:wght@400;500;700;800&family=Orbitron:wght@500;700;800;900&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="antialiased">{children}</body>
    </html>
  );
}