import StoreClient from "@/components/StoreClient";
import { getPublicProducts, getPublicSettings } from "@/lib/store";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const [products, settings] = await Promise.all([
    getPublicProducts(),
    getPublicSettings(),
  ]);
  return <StoreClient products={products} settings={settings} />;
}